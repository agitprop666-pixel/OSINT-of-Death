from __future__ import annotations

import sys
import re
import json
import socket
import subprocess
import time
import hashlib
import random
import urllib.request
import urllib.error
import urllib.parse
import webbrowser
import phonenumbers
from phonenumbers import geocoder, carrier, timezone as pn_timezone
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import queue as _pyqueue
from html import escape as html_escape

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon, QTextCursor
import os
from PyQt6.QtWidgets  import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QTextEdit, QLabel, QComboBox,
    QCheckBox, QSplashScreen, QFileDialog, QFrame, QSplitter,
    QListWidget, QListWidgetItem, QMessageBox, QDialog,
    QTabWidget, QScrollArea, QGroupBox, QGridLayout, QSpinBox,
    QTextBrowser, QRadioButton, QButtonGroup,
)

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────
APP_NAME = "OSINT of Death"
ORG_NAME = "Death's Head Software"
VERSION  = "5.0.0"
APP_ID   = "DeathsHeadSoftware.OSINTofDeath"

C_BG     = "#0A0A0A"
C_PANEL  = "#0D160D"
C_BORDER = "#1A3A1A"
C_GREEN  = "#00FF41"
C_GREEN2 = "#00CC33"
C_DARK   = "#004410"

COL_HEAD  = "#00FFFF"
COL_OK    = "#00FF41"
COL_WARN  = "#FFD700"
COL_ERR   = "#FF4444"
COL_INFO  = "#CCCCCC"
COL_CHAIN = "#FF9900"
COL_WARN  = "#FFD700"   # reuse for settings status labels
COL_MANU  = "#AA88FF"   # purple — manual check items
COL_SEP   = "#1A3A1A"   # dim green — separators

def _get_app_data_dir() -> Path:
    """Returns a writable app data directory — works for both dev and installed builds."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home()))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    d = base / "DeathsHeadSoftware" / "OSINTofDeath"
    d.mkdir(parents=True, exist_ok=True)
    return d

APP_DATA_DIR = _get_app_data_dir()
HISTORY_FILE = APP_DATA_DIR / "osint_history.json"
CONFIG_FILE  = APP_DATA_DIR / "osint_config.json"

MIN_BODY_BYTES   = 8000   # below this → stub/error/challenge page
MIN_USERNAME_OCC = 3      # username must appear at least this many times in body

# ─────────────────────────────────────────────────────────────────────────────
# User-agent pool for rotation
# ─────────────────────────────────────────────────────────────────────────────
UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
]

def rand_ua() -> str:
    return random.choice(UA_POOL)

# ─────────────────────────────────────────────────────────────────────────────
# Site registry
#
# Three tiers:
#   API_SITES    — use a proper API endpoint; enumeration + enrichment in one pass
#   PROBE_SITES  — scrape HTML; body-size + username-occurrence check
#   MANUAL_SITES — unreliable (JS-render / login wall); emit link only, no probe
#
# PROBE_SITES entry: (url_template, [hard_not_found_strings])
# Hard strings are a fast-reject before the body checks; keep them very specific.
# ─────────────────────────────────────────────────────────────────────────────

API_SITES = {
    "GitHub",
    "Reddit",
    "HackerNews",
}

MANUAL_SITES = {
    "LinkedIn":   "https://www.linkedin.com/in/{}",
    "TikTok":     "https://www.tiktok.com/@{}",
    "Telegram":   "https://t.me/{}",
    "Instagram":  "https://www.instagram.com/{}/",
    "Snapchat":   "https://www.snapchat.com/add/{}",
    "Pinterest":  "https://www.pinterest.com/{}/",
    "Twitter/X":  "https://twitter.com/{}",
    "YouTube":    "https://www.youtube.com/@{}",
    "Facebook":   "https://www.facebook.com/{}",
    "Duolingo":   "https://www.duolingo.com/profile/{}",   # echoes username on non-existent accounts
    "Xbox":       "https://xboxgamertag.com/search/{}",    # third-party, unreliable
}

CURATED_PROBE = {
    # Steam: reliable hard string, large profile pages
    "Steam":         ("https://steamcommunity.com/id/{}",          ["the specified profile could not be found"]),
    # Twitch: reliable hard string
    "Twitch":        ("https://www.twitch.tv/{}",                  ["sorry. unless you've got a time machine", "page not found"]),
    # GitLab: use specific 404 title, not bare "404"
    "GitLab":        ("https://gitlab.com/{}",                     ["<title>not found", "page not found · gitlab"]),
    # Pastebin: specific user-not-found page
    "Pastebin":      ("https://pastebin.com/u/{}",                 ["pastebin.com - page not found"]),
    # Keybase: specific
    "Keybase":       ("https://keybase.io/{}",                     ["keybase.io | not found", "isn't a keybase user"]),
    # DevTo: specific
    "DevTo":         ("https://dev.to/{}",                         ["<title>404 not found"]),
    # Mastodon: reliable API — use API not scrape
    "Mastodon":      ("https://mastodon.social/@{}",               ["the page you are looking for could not be found"]),
    # Flickr: specific
    "Flickr":        ("https://www.flickr.com/people/{}/",         ["page not found | flickr"]),
    # Tumblr: specific
    "Tumblr":        ("https://{}.tumblr.com",                     ["there&#39;s nothing here.", "there's nothing here."]),
    # Dribbble: specific
    # Last.fm: specific
    "Last.fm":       ("https://www.last.fm/user/{}",               ["last.fm | error | user not found"]),
    # Soundcloud: specific
    # Vimeo: specific
    # Substack: specific
    "Substack":      ("https://{}.substack.com",                   ["this publication does not exist"]),
    # ProductHunt: specific
    "ProductHunt":   ("https://www.producthunt.com/@{}",           ["page not found | product hunt"]),
    # Quora: specific
    # Gravatar: avatar endpoint is reliable — 404 = no account
    # (handled via HTTP status, not body; hard strings kept broad)
    "Gravatar":      ("https://en.gravatar.com/{}",                ["hmm, we couldn&#39;t find that page", "we couldn't find that page"]),
}

EXTENDED_PROBE_EXTRA = {
    "AboutMe":       ("https://about.me/{}",                       ["about.me | page not found"]),
    "Behance":       ("https://www.behance.net/{}",                ["behance | page not found"]),
    "BitBucket":     ("https://bitbucket.org/{}",                  ["bitbucket | page not found", "repository not found"]),
    "Codepen":       ("https://codepen.io/{}",                     ["<title>codepen | 404", "sorry, we can't find"]),
    "Dailymotion":   ("https://www.dailymotion.com/{}",            ["dailymotion | page not found", "this page does not exist"]),
    "Deviantart":    ("https://{}.deviantart.com",                 ["deviantart | not found", "this user doesn't exist"]),
    "Fiverr":        ("https://www.fiverr.com/{}",                 ["fiverr | page not found", "this page is unavailable"]),
    "Imgur":         ("https://imgur.com/user/{}",                 ["imgur | page not found", "user not found"]),
    "Instructables": ("https://www.instructables.com/member/{}/",  ["we couldn't find the page", "instructables | member not found"]),
    "Kickstarter":   ("https://www.kickstarter.com/profile/{}",    ["the page you were looking for doesn't exist", "kickstarter | 404"]),
    "Letterboxd":    ("https://letterboxd.com/{}",                 ["sorry, we can't find that page", "letterboxd | not found"]),
    "Npmjs":         ("https://www.npmjs.com/~{}",                 ["npm | 404", "user not found"]),
    "Patreon":       ("https://www.patreon.com/{}",                ["this page doesn&#39;t exist", "this page doesn't exist"]),
    "Scribd":        ("https://www.scribd.com/{}",                 ["scribd | page not found", "the page you requested does not exist"]),
    "Unsplash":      ("https://unsplash.com/@{}",                  ["unsplash | 404", "this page could not be found"]),
    "VK":            ("https://vk.com/{}",                         ["this page either does not exist or is private"]),
    "Wattpad":       ("https://www.wattpad.com/user/{}",           ["sorry! we can&#39;t find that page", "wattpad | not found"]),
    "Wikipedia":     ("https://en.wikipedia.org/wiki/User:{}",     ["does not have a user page", "there is currently no text in this page"]),
    "Xing":          ("https://www.xing.com/profile/{}",           ["xing | page not found", "this profile doesn't exist"]),
}

SOCIAL_ENRICH_PLATFORMS = {"GitHub", "Reddit", "HackerNews", "Steam", "Mastodon"}

# Aliases for username enumeration
CURATED_SITES  = CURATED_PROBE
EXTENDED_SITES = {**CURATED_PROBE, **EXTENDED_PROBE_EXTRA}

# ─────────────────────────────────────────────────────────────────────────────
# Input detection
# ─────────────────────────────────────────────────────────────────────────────
INPUT_TYPES = ["Auto-Detect", "Name", "Email", "Phone", "Username", "IP Address", "Domain"]

def detect_input_type(text: str) -> str:
    t = text.strip()
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", t):                    return "IP Address"
    if re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", t):                 return "Email"
    if re.match(r"^([a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,}$", t) and " " not in t: return "Domain"
    if re.match(r"^[\+\d\s\-\(\)]{7,20}$", t) and any(c.isdigit() for c in t): return "Phone"
    if " " in t:                                                      return "Name"
    return "Username"

def generate_name_variants(name: str) -> list[str]:
    parts = name.lower().split()
    if len(parts) < 2:
        return [name.lower().replace(" ", ""), name.lower().replace(" ", "_")]
    first, last = parts[0], parts[-1]
    # middle name intentionally excluded from variants
    variants = [
        f"{first}{last}",         # johnsmith
        f"{first}.{last}",        # john.smith
        f"{first}_{last}",        # john_smith
        f"{first[0]}{last}",      # jsmith
        f"{first[0]}.{last}",     # j.smith
        f"{last}{first}",         # smithjohn
        f"{last}.{first}",        # smith.john
        f"{last}_{first}",        # smith_john
        f"{first[0]}{last[0] if last else ''}", # js
    ]
    # Remove single-char results
    variants = [v for v in variants if len(v) > 3]
    return list(dict.fromkeys(variants))

def extract_emails(text: str) -> list[str]:
    return list(set(re.findall(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", text)))

def extract_ips(text: str) -> list[str]:
    raw     = re.findall(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", text)
    private = re.compile(r"^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|127\.|0\.)")
    return list(set(ip for ip in raw if not private.match(ip)))

def body_confirms(body: str, username: str) -> bool:
    """Return True if body is large enough AND username appears enough times."""
    if len(body) < MIN_BODY_BYTES:
        return False
    return body.lower().count(username.lower()) >= MIN_USERNAME_OCC

# ─────────────────────────────────────────────────────────────────────────────
# History

# ─────────────────────────────────────────────────────────────────────────────
# Config manager
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "keys": {
        "numverify":      "",
        "abstractapi_phone":  "",
        "abstractapi_email":  "",
        "ipinfo":         "",
        "abuseipdb":      "",
        "shodan":         "",
        "hunter":         "",
        "securitytrails": "",
        "virustotal":     "",
        "hibp":           "",
        "anthropic":      "",
        "courtlistener":  "",
        "data_gov":       "",
        "fec":            "",
        "patentsview":    "",
    },
    "scan": {
        "timeout":        300,
        "extended":       False,
        "max_harvester":  200,
        "claude_model":   "claude-haiku-4-5",
        "auto_summarize": True,
    }
}

CLAUDE_MODELS = [
    "claude-haiku-4-5",
    "claude-sonnet-4-6",
]

class ConfigManager:
    def __init__(self):
        self.data = {}
        self.load()

    def load(self):
        if CONFIG_FILE.exists():
            try:
                self.data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            except Exception:
                self.data = {}
        # Fill in any missing keys with defaults
        for section, vals in DEFAULT_CONFIG.items():
            if section not in self.data:
                self.data[section] = {}
            for k, v in vals.items():
                if k not in self.data[section]:
                    self.data[section][k] = v

    def save(self):
        CONFIG_FILE.write_text(
            json.dumps(self.data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )

    def key(self, name: str) -> str:
        return self.data.get("keys", {}).get(name, "").strip()

    def scan(self, name: str):
        return self.data.get("scan", {}).get(name, DEFAULT_CONFIG["scan"].get(name))

    def has_any_key(self) -> bool:
        return any(v.strip() for v in self.data.get("keys", {}).values())

    def set_key(self, name: str, value: str):
        self.data.setdefault("keys", {})[name] = value.strip()

    def set_scan(self, name: str, value):
        self.data.setdefault("scan", {})[name] = value


# ─────────────────────────────────────────────────────────────────────────────
# API validation helpers
# ─────────────────────────────────────────────────────────────────────────────
def _api_get(url: str, headers: dict = None, timeout: int = 8,
             return_error_code: bool = False):
    """Returns parsed JSON dict, or None on failure.
    If return_error_code=True, returns (dict_or_None, http_code_or_None)."""
    try:
        req = urllib.request.Request(url, headers=headers or {"User-Agent": "OSINTofDeath/4.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8", errors="replace"))
            return (d, r.status) if return_error_code else d
    except urllib.error.HTTPError as e:
        if return_error_code:
            try:
                body = json.loads(e.read().decode("utf-8", errors="replace"))
            except Exception:
                body = None
            return (body, e.code)
        return None
    except Exception:
        return (None, None) if return_error_code else None

def validate_api_key(name: str, key: str) -> tuple[bool, str]:
    """Returns (ok, message).

    Strategy per API:
    - If the API returns different HTTP codes for valid vs invalid keys → use HTTP code
    - If the API returns 403 for both valid and invalid (IP/host restrictions) → use key format check
    - Always treat 429 (rate limit) as "key is valid but rate limited"
    """
    import re as _re
    key = key.strip()
    if not key:
        return False, "No key provided"

    try:
        # ── Format-only validators (APIs that 403 on IP restrictions regardless of key) ──
        # AbstractAPI: 32-char hex keys
        if name == "abstractapi_phone":
            if _re.match(r"^[a-f0-9]{32}$", key.lower()):
                return True, "Key format valid — will confirm on first scan"
            return False, "Invalid format — AbstractAPI keys are 32 hex characters"

        if name == "abstractapi_email":
            if _re.match(r"^[a-f0-9]{32}$", key.lower()):
                return True, "Key format valid — will confirm on first scan"
            return False, "Invalid format — AbstractAPI keys are 32 hex characters"

        # ── Live validators ──────────────────────────────────────────────────────
        if name == "numverify":
            # NumVerify: free tier HTTP only. Error: {"success":false,"error":{"code":101,"info":"..."}}
            d, code = _api_get(
                f"http://apilayer.net/api/validate?access_key={key}&number=14158586273",
                return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if not d.get("success", True):
                err = d.get("error", {})
                info = err.get("info", str(err)) if isinstance(err, dict) else str(err)
                return False, info
            return True, f"OK — {d.get('country_name','')}"

        if name == "ipinfo":
            # IPInfo: {"error":{"title":"...","message":"...","status":401}} on bad key
            d, code = _api_get(f"https://ipinfo.io/8.8.8.8?token={key}", return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            err = d.get("error")
            if err:
                msg = err.get("message", err.get("title", str(err))) if isinstance(err, dict) else str(err)
                return False, msg
            if d.get("ip"): return True, f"OK — org: {d.get('org','')}"
            return False, "Unexpected response"

        if name == "abuseipdb":
            # AbuseIPDB: {"errors":[{"detail":"...","status":401}]} on bad key
            d, code = _api_get(
                "https://api.abuseipdb.com/api/v2/check?ipAddress=8.8.8.8",
                headers={"Key": key, "Accept": "application/json"},
                return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if "errors" in d:
                return False, d["errors"][0].get("detail", "Invalid key")
            if "data" in d: return True, "OK"
            return False, "Unexpected response"

        if name == "shodan":
            # Shodan: {"error":"Invalid API key."} on bad key
            d, code = _api_get(f"https://api.shodan.io/api-info?key={key}", return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if d.get("error"): return False, str(d["error"])
            if "plan" in d or "query_credits" in d:
                return True, f"Plan: {d.get('plan','?')} — credits: {d.get('query_credits','?')}"
            return False, "Unexpected response"

        if name == "hunter":
            # Hunter: {"errors":[{"id":"unauthorized","code":401,"details":"..."}]} on bad key
            d, code = _api_get(f"https://api.hunter.io/v2/account?api_key={key}", return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if d.get("errors"):
                return False, d["errors"][0].get("details", "Invalid key")
            searches = d.get("data",{}).get("requests",{}).get("searches",{})
            return True, f"OK — {searches.get('used',0)}/{searches.get('available','?')} searches used"

        if name == "securitytrails":
            # SecurityTrails: {"message":"Unauthorized. Invalid or missing apikey."} on bad key
            d, code = _api_get(
                "https://api.securitytrails.com/v1/ping",
                headers={"APIKEY": key},
                return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if code == 200 and d and d.get("success") is True: return True, "OK"
            if d is None:   return False, f"Request failed (HTTP {code})"
            msg = d.get("message","")
            if any(w in msg.lower() for w in ["unauthorized","invalid","missing"]):
                return False, msg
            return True, "OK"

        if name == "virustotal":
            # VirusTotal: {"error":{"code":"AuthenticationRequiredError","message":"..."}} on bad key
            d, code = _api_get(
                "https://www.virustotal.com/api/v3/ip_addresses/8.8.8.8",
                headers={"x-apikey": key},
                return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if d.get("error"):
                err = d["error"]
                return False, err.get("message", str(err)) if isinstance(err, dict) else str(err)
            if d.get("data"): return True, "OK"
            return False, "Unexpected response"

        if name == "courtlistener":
            # CourtListener: {"detail":"Invalid token."} on bad key, 200+results on good key
            d, code = _api_get(
                "https://www.courtlistener.com/api/rest/v4/dockets/?q=test&page_size=1",
                headers={"Authorization": f"Token {key}"},
                return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if isinstance(d, dict):
                detail = str(d.get("detail","")).lower()
                if any(w in detail for w in ["invalid","unauthorized","forbidden"]):
                    return False, d.get("detail","Invalid token")
                if "count" in d or "results" in d:
                    return True, f"OK — {d.get('count',0)} accessible results"
                # Any other 200 dict — treat as valid
                return True, "OK"
            return True, "OK"

        if name == "patentsview":
            # PatentsView: requires X-Api-Key header since March 2026 migration
            d, code = _api_get(
                'https://search.patentsview.org/api/v1/patent/?q={"patent_id":"9000000"}&f=["patent_id","patent_title"]&o={"size":1}',
                headers={"X-Api-Key": key, "User-Agent": "OSINTofDeath/5.0"},
                return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if code == 401: return False, "Invalid API key"
            if d is None:   return False, f"Request failed (HTTP {code})"
            if isinstance(d, dict):
                if d.get("error"): return False, str(d["error"])
                return True, f"OK — {d.get('total_hits','?')} patents accessible"
            return True, "OK"

        if name == "hibp":
            # HIBP: use official integration testing address (guaranteed breach hit)
            req = urllib.request.Request(
                "https://haveibeenpwned.com/api/v3/breachedaccount/account-exists@hibp-integration-testing.com",
                headers={"hibp-api-key": key, "User-Agent": "OSINTofDeath/5.0"}
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as r:
                    return True, f"OK — key valid (HTTP {r.status})"
            except urllib.error.HTTPError as e:
                if e.code == 200:  return True, "OK"
                if e.code == 404:  return True, "OK — key valid"
                if e.code == 401:  return False, "Invalid API key"
                if e.code == 403:  return False, "Forbidden — check subscription"
                if e.code == 429:  return True, "Rate limited — key valid"
                return False, f"HTTP {e.code}"

        if name in ("data_gov", "fec"):
            svc = "College Scorecard" if name == "data_gov" else "FEC"
            # Both APIs return {"error":"API_KEY_INVALID"} on bad key
            url = (f"https://api.data.gov/ed/collegescorecard/v1/schools"
                   f"?school.name=Harvard&fields=school.name&per_page=1&api_key={key}"
                   if name == "data_gov" else
                   f"https://api.open.fec.gov/v1/candidates/?api_key={key}&per_page=1")
            d, code = _api_get(url, return_error_code=True)
            if code == 429: return True, "Rate limited — key valid"
            if d is None:   return False, f"Request failed (HTTP {code})"
            err = d.get("error","") if isinstance(d, dict) else ""
            if err == "API_KEY_INVALID":  return False, "Invalid API key"
            if err == "API_KEY_MISSING":  return False, "No API key"
            if err == "OVER_RATE_LIMIT":  return True, "Rate limited — key valid"
            if d.get("results") is not None or d.get("data") is not None:
                return True, f"OK — {svc} accessible"
            if isinstance(d, dict) and not err:
                return True, f"OK — {svc} accessible"
            return False, f"Unexpected: {str(d)[:80]}"

        if name == "anthropic":
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=json.dumps({
                    "model": "claude-haiku-4-5",
                    "max_tokens": 10,
                    "messages": [{"role": "user", "content": "hi"}]
                }).encode(),
                headers={
                    "x-api-key": key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                }
            )
            req.get_method = lambda: "POST"
            try:
                with urllib.request.urlopen(req, timeout=10) as r:
                    return True, "OK — Anthropic accessible"
            except urllib.error.HTTPError as e:
                if e.code == 401: return False, "Invalid API key"
                if e.code == 403: return False, "Forbidden — check key permissions"
                if e.code == 429: return True, "Rate limited — key valid"
                if e.code == 400:
                    try:
                        body = json.loads(e.read().decode())
                        return False, body.get("error",{}).get("message","Bad request")
                    except Exception:
                        return False, "Bad request"
                return False, f"HTTP {e.code}"

        return False, f"Unknown API: {name}"

    except Exception as e:
        return False, f"Error: {str(e)[:80]}"



# ─────────────────────────────────────────────────────────────────────────────
# Settings Dialog
# ─────────────────────────────────────────────────────────────────────────────
SETDLG_STYLE = f"""
    QDialog, QWidget, QTabWidget, QGroupBox {{
        background:{C_BG}; color:{C_GREEN}; font-family:Courier;
    }}
    QTabBar::tab {{
        background:#2A2A2A; color:#FFFFFF; border:1px solid {C_BORDER};
        padding:6px 16px; font-family:Courier; font-size:12px; font-weight:bold;
    }}
    QTabBar::tab:selected {{ background:{C_DARK}; color:#FFFFFF; border-bottom:2px solid {C_GREEN}; }}
    QTabBar::tab:hover {{ background:#333333; color:#FFFFFF; }}
    QLineEdit {{
        background:{C_PANEL}; color:{C_GREEN}; border:1px solid {C_BORDER};
        padding:4px; font-family:Courier; font-size:12px;
    }}
    QLabel {{ color:{C_GREEN2}; font-family:Courier; font-size:12px; }}
    QPushButton {{
        background:{C_DARK}; color:{C_GREEN}; border:1px solid {C_GREEN2};
        padding:5px 12px; font-family:Courier; font-size:12px; font-weight:bold;
    }}
    QPushButton:hover {{ background:#005500; }}
    QGroupBox {{
        border:1px solid {C_BORDER}; margin-top:8px; padding:8px;
        font-family:Courier; font-size:12px; color:{C_GREEN2};
    }}
    QGroupBox::title {{ subcontrol-origin:margin; left:8px; color:{C_GREEN}; }}
    QSpinBox {{
        background:{C_PANEL}; color:{C_GREEN}; border:1px solid {C_BORDER};
        padding:4px; font-family:Courier;
    }}
    QComboBox {{
        background:{C_PANEL}; color:{C_GREEN}; border:1px solid {C_BORDER};
        padding:4px; font-family:Courier;
    }}
    QComboBox QAbstractItemView {{
        background:{C_PANEL}; color:{C_GREEN};
        selection-background-color:{C_DARK};
    }}
    QCheckBox {{ color:{C_GREEN2}; font-family:Courier; }}
    QRadioButton {{ color:{C_GREEN}; font-family:Courier; font-size:12px; }}
    QRadioButton::indicator {{ width:13px; height:13px; }}
    QCheckBox::indicator {{ width:13px; height:13px; border:1px solid {C_GREEN2}; background:{C_PANEL}; }}
    QCheckBox::indicator:checked {{ background:{C_GREEN2}; }}
    QScrollArea {{ border:none; background:{C_BG}; }}
"""
DLGSTYLE = SETDLG_STYLE  # alias for HistoryDialog

# Each entry:
# (key_name, label, signup_url, key_url, free_info, hint_line, help_text)
API_DEFS = [
    (
        "numverify",
        "NumVerify — Phone Validation",
        "https://numverify.com",
        "https://numverify.com/dashboard",
        "100 lookups/mo free",
        "Carrier, line type, country, validity · 100/mo free · HTTP only on free tier",
        (
            "What it does:\n"
            "  Validates phone numbers and returns carrier, line type (mobile/landline/VOIP),\n"
            "  country, location, and whether the number is valid.\n"
            "\n"
            "Free tier: 100 lookups/month (HTTP only — HTTPS requires paid plan)\n"
            "\n"
            "How to get your key:\n"
            "  1. Go to https://numverify.com and click 'Get Free API Key'\n"
            "  2. Create a free account\n"
            "  3. Your API key is shown on the Dashboard at https://numverify.com/dashboard\n"
            "\n"
            "Gotcha: The free plan uses HTTP (not HTTPS). This is handled automatically."
        ),
    ),
    (
        "abstractapi_phone",
        "AbstractAPI — Phone Validation",
        "https://app.abstractapi.com/users/signup",
        "https://app.abstractapi.com/api/phone-validation/tester",
        "250 lookups/mo free",
        "Carrier, type, country detail · 250/mo free · separate key from email API",
        (
            "What it does:\n"
            "  Validates phone numbers and returns carrier, line type, country, and\n"
            "  formatted number variants.\n"
            "\n"
            "Free tier: 250 lookups/month\n"
            "\n"
            "How to get your key:\n"
            "  1. Sign up at https://app.abstractapi.com/users/signup\n"
            "  2. In the dashboard, go to 'Phone Validation' API\n"
            "  3. Your API key is shown at https://app.abstractapi.com/api/phone-validation/tester\n"
            "\n"
            "Gotcha: AbstractAPI has separate keys per product. This key is ONLY for\n"
            "  phone validation. The email key below is different."
        ),
    ),
    (
        "abstractapi_email",
        "AbstractAPI — Email Validation",
        "https://app.abstractapi.com/users/signup",
        "https://app.abstractapi.com/api/email-validation/tester",
        "100 lookups/mo free",
        "Deliverability, disposable check, SMTP · 100/mo free · separate key from phone API",
        (
            "What it does:\n"
            "  Validates email addresses and returns deliverability score, whether the\n"
            "  address is disposable/role/free, MX record status, and SMTP validity.\n"
            "\n"
            "Free tier: 100 lookups/month\n"
            "\n"
            "How to get your key:\n"
            "  1. Sign up at https://app.abstractapi.com/users/signup\n"
            "  2. In the dashboard, go to 'Email Validation' API\n"
            "  3. Your API key is shown at https://app.abstractapi.com/api/email-validation/tester\n"
            "\n"
            "Gotcha: This is a DIFFERENT key from the phone validation key above.\n"
            "  Each AbstractAPI product has its own separate key."
        ),
    ),
    (
        "ipinfo",
        "IPInfo — IP Intelligence",
        "https://ipinfo.io/signup",
        "https://ipinfo.io/account/token",
        "50,000 lookups/mo free",
        "Hostname, org, privacy/VPN flag, abuse contact · 50k/mo free",
        (
            "What it does:\n"
            "  Enriches IP addresses with hostname, ASN, organisation, city, region,\n"
            "  country, timezone, and privacy flags (VPN/proxy/Tor detection).\n"
            "  The paid tier adds abuse contact info.\n"
            "\n"
            "Free tier: 50,000 lookups/month\n"
            "\n"
            "How to get your key:\n"
            "  1. Sign up at https://ipinfo.io/signup\n"
            "  2. Your token is at https://ipinfo.io/account/token\n"
            "\n"
            "Gotcha: The free tier includes VPN/proxy detection but not full privacy\n"
            "  data (hosting provider, relay, etc.) — that requires a paid plan."
        ),
    ),
    (
        "abuseipdb",
        "AbuseIPDB — IP Reputation",
        "https://www.abuseipdb.com/register",
        "https://www.abuseipdb.com/account/api",
        "1,000 checks/day free",
        "Abuse score, report count, ISP, Tor flag · 1k/day free",
        (
            "What it does:\n"
            "  Checks an IP address against a crowdsourced database of abuse reports.\n"
            "  Returns a confidence score (0-100%), total report count, ISP, usage type,\n"
            "  and whether the IP is a known Tor exit node.\n"
            "\n"
            "Free tier: 1,000 checks/day\n"
            "\n"
            "How to get your key:\n"
            "  1. Register at https://www.abuseipdb.com/register\n"
            "  2. Verify your email\n"
            "  3. Your API key is at https://www.abuseipdb.com/account/api\n"
            "\n"
            "Gotcha: Account requires email verification before the API key is active."
        ),
    ),
    (
        "shodan",
        "Shodan — Port & Banner Scanning",
        "https://account.shodan.io/register",
        "https://account.shodan.io",
        "Free (1 result/query, no filters)",
        "Open ports, banners, OS, hostnames · free account required · 1 result/query on free",
        (
            "What it does:\n"
            "  Scans the internet for open ports and service banners. Returns open ports,\n"
            "  service banners, OS detection, hostnames, and organisation info for any IP.\n"
            "\n"
            "Free tier: API access with 1 result per query, no filters.\n"
            "  (The paid 'Freelancer' plan at $49/mo removes all limits.)\n"
            "\n"
            "How to get your key:\n"
            "  1. Create an account at https://account.shodan.io/register\n"
            "  2. Confirm your email\n"
            "  3. Your API key is shown at https://account.shodan.io (top of page)\n"
            "\n"
            "Gotcha: Free accounts can query host info but cannot use search filters\n"
            "  or download bulk data. The key itself is free — no credit card needed."
        ),
    ),
    (
        "hunter",
        "Hunter.io — Email Intelligence",
        "https://hunter.io/users/sign_up",
        "https://hunter.io/api-keys",
        "25 searches/mo free",
        "Email verify, deliverability, score, SMTP, disposable check · 25/mo free",
        (
            "What it does:\n"
            "  Verifies email addresses and returns a deliverability score, SMTP check,\n"
            "  whether the address is disposable/webmail, MX record status, and a\n"
            "  confidence score. Also finds email addresses associated with a domain.\n"
            "\n"
            "Free tier: 25 searches/month\n"
            "\n"
            "How to get your key:\n"
            "  1. Sign up at https://hunter.io/users/sign_up\n"
            "  2. Your API key is at https://hunter.io/api-keys\n"
            "\n"
            "Gotcha: The free tier covers email verification. Domain search (finding\n"
            "  all emails at a company) uses a separate request type."
        ),
    ),
    (
        "securitytrails",
        "SecurityTrails — DNS History",
        "https://securitytrails.com/app/signup",
        "https://securitytrails.com/app/account/credentials",
        "50 queries/mo free",
        "DNS history, subdomains, WHOIS history · 50/mo free",
        (
            "What it does:\n"
            "  Returns current and historical DNS records, subdomain lists, WHOIS history,\n"
            "  and associated IPs for any domain. Excellent for tracking infrastructure\n"
            "  changes and finding hidden subdomains.\n"
            "\n"
            "Free tier: 50 API queries/month\n"
            "\n"
            "How to get your key:\n"
            "  1. Sign up at https://securitytrails.com/app/signup\n"
            "  2. Verify your email\n"
            "  3. Your API key is at https://securitytrails.com/app/account/credentials\n"
            "\n"
            "Gotcha: Account requires email verification. The free tier is quite limited\n"
            "  (50 queries total per month) so use it for high-value targets."
        ),
    ),
    (
        "virustotal",
        "VirusTotal — Malware & Reputation",
        "https://www.virustotal.com/gui/join-us",
        "https://www.virustotal.com/gui/my-apikey",
        "500 lookups/day free",
        "Malware scan, reputation score, categories, DNS records · 500/day free",
        (
            "What it does:\n"
            "  Checks domains, IPs, and files against 70+ antivirus engines and\n"
            "  reputation databases. Returns malicious/suspicious/clean verdicts,\n"
            "  site categories, DNS records, WHOIS, and relationship data.\n"
            "\n"
            "Free tier: 500 lookups/day, 4 lookups/minute rate limit\n"
            "\n"
            "How to get your key:\n"
            "  1. Create an account at https://www.virustotal.com/gui/join-us\n"
            "  2. Your API key is at https://www.virustotal.com/gui/my-apikey\n"
            "\n"
            "Gotcha: The free public API has a 4 requests/minute rate limit.\n"
            "  Exceeding it returns HTTP 429 — the app handles this gracefully."
        ),
    ),
    (
        "hibp",
        "HaveIBeenPwned — Breach Data",
        "https://haveibeenpwned.com/API/Key",
        "https://haveibeenpwned.com/API/Key",
        "$3.50/month (no free tier)",
        "Data breach lookup — which breaches an email appeared in · $3.50/mo · no free tier",
        (
            "What it does:\n"
            "  Checks an email address against Troy Hunt's database of data breaches.\n"
            "  Returns every breach the email appeared in, with breach date and what\n"
            "  data was exposed (passwords, addresses, phone numbers, etc.).\n"
            "\n"
            "Pricing: $3.50/month flat — unlimited queries, no free tier for the API.\n"
            "  (You can check manually for free at haveibeenpwned.com)\n"
            "\n"
            "How to get your key:\n"
            "  1. Go to https://haveibeenpwned.com/API/Key\n"
            "  2. Enter your email address and pay ($3.50/mo via Stripe)\n"
            "  3. Your API key is emailed to you immediately after payment\n"
            "\n"
            "Gotcha: The key is tied to your email address. It arrives by email\n"
            "  within a few minutes of subscribing."
        ),
    ),
    (
        "anthropic",
        "Anthropic — Claude AI Summary",
        "https://console.anthropic.com",
        "https://console.anthropic.com/settings/keys",
        "Pay per use (~$0.001/summary)",
        "AI intelligence report from scan findings · pay per use · ~$0.001 per summary with Haiku",
        (
            "What it does:\n"
            "  After each scan, sends your findings to Claude (Anthropic's AI) and\n"
            "  generates a full intelligence report with executive summary, risk\n"
            "  assessment, digital footprint analysis, and recommended next steps.\n"
            "\n"
            "Pricing: Pay per token used.\n"
            "  · claude-haiku-4-5  : ~$0.001 per summary (fast, cheap)\n"
            "  · claude-sonnet-4-6 : ~$0.01  per summary (more thorough)\n"
            "  Add credit at https://console.anthropic.com/settings/billing\n"
            "\n"
            "How to get your key:\n"
            "  1. Create an account at https://console.anthropic.com\n"
            "  2. Add billing credit (minimum $5)\n"
            "  3. Your API key is at https://console.anthropic.com/settings/keys\n"
            "  4. Click 'Create Key', give it a name, copy it immediately\n"
            "\n"
            "Gotcha: API keys are only shown ONCE at creation — copy it right away.\n"
            "  If you lose it, create a new one (old one can be revoked)."
        ),
    ),
    (
        "patentsview",
        "PatentsView — USPTO Patents",
        "https://data.uspto.gov/myodp",
        "https://data.uspto.gov/myodp",
        "Free — USPTO.gov account + ID.me verification required",
        "US patent search by inventor · free · requires USPTO.gov account verified with ID.me",
        (
            "What it does:\n"
            "  Searches USPTO patent records by inventor name. Returns patent numbers,\n"
            "  titles, dates, and assignee organisations.\n"
            "\n"
            "Free tier: Free with API key\n"
            "\n"
            "How to get your key:\n"
            "  1. Create a USPTO.gov account at https://www.uspto.gov\n"
            "  2. Verify your account with ID.me (identity verification required)\n"
            "  3. Go to https://data.uspto.gov/myodp to get your API key\n"
            "  4. Paste the key here\n"
            "\n"
            "Gotcha: PatentsView migrated to the USPTO Open Data Portal in March 2026.\n"
            "  A USPTO.gov account verified with ID.me is now required for API access.\n"
            "  Without a key, patent searches will return no results."
        ),
    ),
    (
        "data_gov",
        "Data.gov — College Scorecard",
        "https://api.data.gov/signup/",
        "https://api.data.gov/signup/",
        "Free — 1,000/day with key vs 40/day DEMO_KEY",
        "College Scorecard education data · free key · 1k/day vs 40/day without",
        (
            "What it does:\n"
            "  Powers the Education module in Deep Search. Searches the US Dept of\n"
            "  Education College Scorecard database for institutions.\n"
            "  Returns school name, city, state, size, and URL.\n"
            "\n"
            "Without key: works with DEMO_KEY (40 requests/day limit)\n"
            "With key: 1,000 requests/day\n"
            "\n"
            "How to get your key:\n"
            "  1. Go to https://api.data.gov/signup/\n"
            "  2. Enter your name and email — key sent immediately\n"
            "  3. Check your email and paste the key here\n"
            "\n"
            "Gotcha: Same key works for FEC API below — only one signup needed."
        ),
    ),
    (
        "fec",
        "FEC — Campaign Finance",
        "https://api.open.fec.gov/developers/",
        "https://api.open.fec.gov/developers/",
        "Free — 1,000/day with key vs 40/day DEMO_KEY",
        "FEC donation records by name · free key · 1k/day vs 40/day without",
        (
            "What it does:\n"
            "  Powers the Campaign Finance module in Deep Search. Searches FEC records\n"
            "  for political donations — returns amount, recipient, date, employer.\n"
            "\n"
            "Without key: works with DEMO_KEY (40 requests/day limit)\n"
            "With key: 1,000 requests/day\n"
            "\n"
            "How to get your key:\n"
            "  1. Go to https://api.open.fec.gov/developers/\n"
            "  2. Click 'Get an API Key' and enter your email\n"
            "  3. Key sent immediately to your email\n"
            "\n"
            "Gotcha: The Data.gov key (above) works here too — same system."
        ),
    ),
    (
        "courtlistener",
        "CourtListener — Court Records",
        "https://www.courtlistener.com/sign-in/",
        "https://www.courtlistener.com/profile/",
        "Free account required",
        "Federal/state court dockets · free account · token from profile page",
        (
            "What it does:\n"
            "  Searches millions of federal and state court dockets and opinions.\n"
            "  Returns case names, courts, filing dates, and links to documents.\n"
            "\n"
            "Free tier: Unlimited with free account\n"
            "\n"
            "How to get your key:\n"
            "  1. Create free account at https://www.courtlistener.com/sign-in/\n"
            "  2. Go to https://www.courtlistener.com/profile/\n"
            "  3. Click the API Token section and copy your token\n"
            "\n"
            "Gotcha: Use the token directly — no Bearer prefix needed."
        ),
    ),
]

class SettingsDialog(QDialog):
    def __init__(self, config: ConfigManager, parent=None):
        super().__init__(parent)
        self.config = config
        self.key_fields: dict[str, QLineEdit] = {}
        self.status_labels: dict[str, QLabel] = {}
        self.setWindowTitle("Settings — OSINT of Death")
        self.setMinimumSize(720, 580)
        self.setStyleSheet(SETDLG_STYLE)

        root = QVBoxLayout(self)
        tabs = QTabWidget()
        root.addWidget(tabs)

        tabs.addTab(self._build_api_tab(),  "⚙  API Keys")
        tabs.addTab(self._build_scan_tab(), "🔍  Scan Settings")
        tabs.addTab(self._build_about_tab(),"ℹ  About")

        btn_row = QHBoxLayout()
        save_btn  = QPushButton("💾  Save")
        close_btn = QPushButton("✗  Close")
        save_btn.clicked.connect(self._save)
        close_btn.clicked.connect(self.reject)
        btn_row.addStretch()
        btn_row.addWidget(save_btn)
        btn_row.addWidget(close_btn)
        root.addLayout(btn_row)

    def _build_api_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(8)

        for entry in API_DEFS:
            key_name, label, signup_url, key_url, free_info, hint_line, help_text = entry

            grp = QGroupBox(f"{label}  [{free_info}]")
            grid = QGridLayout(grp)
            grid.setSpacing(6)

            # Row 0: key field + controls
            fld = QLineEdit()
            fld.setEchoMode(QLineEdit.EchoMode.Password)
            fld.setPlaceholderText("Paste API key here...")
            fld.setText(self.config.key(key_name))
            self.key_fields[key_name] = fld

            show_cb = QCheckBox("Show")
            show_cb.stateChanged.connect(
                lambda state, f=fld: f.setEchoMode(
                    QLineEdit.EchoMode.Normal if state else QLineEdit.EchoMode.Password
                )
            )

            test_btn = QPushButton("Test")
            test_btn.setFixedWidth(55)
            test_btn.clicked.connect(lambda _, k=key_name: self._test_key(k))

            key_btn = QPushButton("Get Key  ↗")
            key_btn.setFixedWidth(100)
            key_btn.setToolTip(f"Open: {key_url}")
            key_btn.clicked.connect(lambda _, u=key_url: webbrowser.open(u))

            help_btn = QPushButton("?")
            help_btn.setFixedWidth(28)
            help_btn.setToolTip("How to get this key")
            help_btn.clicked.connect(
                lambda _, lbl=label, txt=help_text, ku=key_url, su=signup_url:
                    self._show_api_help(lbl, txt, su, ku)
            )

            grid.addWidget(QLabel("Key:"), 0, 0)
            grid.addWidget(fld,            0, 1)
            grid.addWidget(show_cb,        0, 2)
            grid.addWidget(test_btn,       0, 3)
            grid.addWidget(key_btn,        0, 4)
            grid.addWidget(help_btn,       0, 5)

            # Row 1: status
            status = QLabel("—")
            self.status_labels[key_name] = status
            grid.addWidget(QLabel("Status:"), 1, 0)
            grid.addWidget(status,            1, 1, 1, 5)

            # Row 2: inline hint
            hint = QLabel(f"ℹ  {hint_line}")
            hint.setWordWrap(True)
            hint.setStyleSheet(f"color:#888888; font-size:10px; font-family:Courier;")
            grid.addWidget(hint, 2, 0, 1, 6)

            layout.addWidget(grp)

        layout.addStretch()
        scroll.setWidget(container)
        return scroll

    def _show_api_help(self, label: str, text: str, signup_url: str, key_url: str):
        dlg = QDialog(self)
        dlg.setWindowTitle(f"How to get: {label}")
        dlg.setMinimumSize(560, 420)
        dlg.setStyleSheet(SETDLG_STYLE)

        root = QVBoxLayout(dlg)

        title = QLabel(label)
        title.setFont(QFont("Courier", 13, QFont.Weight.Bold))
        title.setStyleSheet(f"color:{C_GREEN};")
        root.addWidget(title)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color:{C_BORDER};")
        root.addWidget(sep)

        body = QTextEdit()
        body.setReadOnly(True)
        body.setPlainText(text)
        body.setFont(QFont("Courier", 11))
        body.setStyleSheet(
            f"background:{C_PANEL}; color:#CCCCCC; border:1px solid {C_BORDER};"
        )
        root.addWidget(body)

        btn_row = QHBoxLayout()
        signup_btn = QPushButton("Sign Up ↗")
        signup_btn.clicked.connect(lambda: webbrowser.open(signup_url))
        key_pg_btn = QPushButton("API Key Page ↗")
        key_pg_btn.clicked.connect(lambda: webbrowser.open(key_url))
        close_btn  = QPushButton("Close")
        close_btn.clicked.connect(dlg.accept)
        for b in [signup_btn, key_pg_btn, close_btn]:
            btn_row.addWidget(b)
        root.addLayout(btn_row)

        dlg.exec()

    def _build_scan_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(14)

        # Timeout
        grp1 = QGroupBox("Timeouts")
        g1   = QGridLayout(grp1)
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(30, 1800)
        self.timeout_spin.setSuffix(" seconds")
        self.timeout_spin.setValue(int(self.config.scan("timeout")))
        g1.addWidget(QLabel("theHarvester timeout:"), 0, 0)
        g1.addWidget(self.timeout_spin, 0, 1)
        layout.addWidget(grp1)

        # Defaults
        grp2 = QGroupBox("Defaults")
        g2   = QGridLayout(grp2)
        self.ext_default_cb = QCheckBox("Extended scan on by default")
        self.ext_default_cb.setChecked(bool(self.config.scan("extended")))
        self.auto_summarize_cb = QCheckBox("Auto-summarize with Claude after each scan")
        self.auto_summarize_cb.setChecked(bool(self.config.scan("auto_summarize")))
        g2.addWidget(self.ext_default_cb,    0, 0)
        g2.addWidget(self.auto_summarize_cb, 1, 0)
        layout.addWidget(grp2)

        # Claude model — QListWidget (most stable in compiled builds)
        grp3 = QGroupBox("Claude AI Model")
        g3   = QVBoxLayout(grp3)
        self._model_list = QListWidget()
        self._model_list.setFixedHeight(60)
        self._model_list.setStyleSheet(
            "QListWidget { background: #0D160D; color: #00FF41; "
            "border: 1px solid #1A3A1A; font-family: Courier; font-size: 12px; }"
            "QListWidget::item:selected { background: #004410; color: #00FF41; }"
        )
        cur = self.config.scan("claude_model") or "claude-haiku-4-5"
        model_labels = [
            ("claude-haiku-4-5",  "claude-haiku-4-5   — fast, cheap (~$0.001/summary)"),
            ("claude-sonnet-4-6", "claude-sonnet-4-6  — thorough  (~$0.01/summary)"),
        ]
        for model_id, label in model_labels:
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, model_id)
            self._model_list.addItem(item)
            if model_id == cur:
                self._model_list.setCurrentItem(item)
        if self._model_list.currentItem() is None:
            self._model_list.setCurrentRow(0)
        g3.addWidget(self._model_list)
        layout.addWidget(grp3)

        layout.addStretch()
        return w

    def _build_about_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        for line in [
            f"  {APP_NAME}  v{VERSION}",
            f"  {ORG_NAME}",
            "",
            "  Modules:",
            "  · Username enumeration (20 curated / 60+ extended sites)",
            "  · Name → variant generation + enumeration",
            "  · Google dork link generation",
            "  · theHarvester integration (requires GitHub install)",
            "  · Email analysis + Gravatar check",
            "  · DNS enumeration + subdomain brute-force",
            "  · Phone analysis (phonenumbers library + optional APIs)",
            "  · IP geolocation (ip-api.com + optional IPInfo/AbuseIPDB)",
            "  · WHOIS lookup",
            "  · Domain → IP resolution + cert transparency (crt.sh)",
            "  · Wayback Machine snapshot history",
            "  · Shodan public search + optional API",
            "  · Paste site search (Google dorks + GitHub code search)",
            "  · Social profile enrichment (GitHub/Reddit/HN/Steam/Mastodon)",
            "  · Result chaining (auto-scan discovered emails/IPs)",
            "  · Claude AI intelligence summary",
            "  · Deep Search: education, employers, patents, courts, SEC, FEC,",
            "    property, voter, genealogy, news, arrests, code, domains",
            "",
            "  Data attributions:",
            "  · OpenCorporates (opencorporates.com) — company/officer data",
            "",
            "  Config : osint_config.json  (next to script)",
            "  History: osint_history.json (next to script)",
        ]:
            lbl = QLabel(line)
            lbl.setFont(QFont("Courier", 11))
            lbl.setStyleSheet(f"color:{'#00FF41' if line.startswith('  ·') else '#CCCCCC'};")
            layout.addWidget(lbl)
        return w

    def _test_key(self, key_name: str):
        key   = self.key_fields[key_name].text().strip()
        lbl   = self.status_labels[key_name]
        lbl.setText("Testing...")
        lbl.setStyleSheet(f"color:{C_GREEN2};")
        QApplication.processEvents()

        def do_test():
            ok, msg = validate_api_key(key_name, key)
            return ok, msg

        import threading
        result = [None, None]
        def run():
            result[0], result[1] = do_test()
        t = threading.Thread(target=run, daemon=True)
        t.start()
        t.join(timeout=15)
        ok, msg = result
        if ok is None:
            lbl.setText("⚠ Timed out")
            lbl.setStyleSheet(f"color:{C_WARN};")
        elif ok:
            lbl.setText(f"✓ Valid — {msg}")
            lbl.setStyleSheet(f"color:{COL_OK};")
        else:
            lbl.setText(f"✗ Failed — {msg}")
            lbl.setStyleSheet(f"color:{COL_ERR};")

    def _save(self):
        for key_name, fld in self.key_fields.items():
            self.config.set_key(key_name, fld.text().strip())
        self.config.set_scan("timeout",        self.timeout_spin.value())
        self.config.set_scan("extended",       self.ext_default_cb.isChecked())
        self.config.set_scan("auto_summarize", self.auto_summarize_cb.isChecked())
        item = self._model_list.currentItem()
        if item:
            self.config.set_scan("claude_model",
                item.data(Qt.ItemDataRole.UserRole))
        self.config.save()
        QMessageBox.information(self, "Saved", "Settings saved.")
        self.accept()


# ─────────────────────────────────────────────────────────────────────────────
class HistoryManager:
    def __init__(self):
        self.entries: list[dict] = []
        self.load()

    def load(self):
        if HISTORY_FILE.exists():
            try:
                self.entries = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            except Exception:
                self.entries = []

    def save(self):
        try:
            HISTORY_FILE.write_text(
                json.dumps(self.entries, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
        except Exception:
            pass

    def add(self, query: str, input_type: str, log_text: str):
        self.entries.insert(0, {
            "query":     query,
            "type":      input_type,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "log":       log_text,
        })
        self.entries = self.entries[:200]
        self.save()

# ─────────────────────────────────────────────────────────────────────────────
# HTTP helper
# ─────────────────────────────────────────────────────────────────────────────
def http_get(url: str, timeout: int = 10, json_resp: bool = False,
             ua: str | None = None):
    req = urllib.request.Request(
        url, headers={"User-Agent": ua or rand_ua(),
                      "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
                      "Accept-Language": "en-US,en;q=0.5"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw  = resp.read()
        text = raw.decode("utf-8", errors="replace")
        if json_resp:
            return json.loads(text)
        return text

# ─────────────────────────────────────────────────────────────────────────────
# OSINT Worker
# ─────────────────────────────────────────────────────────────────────────────
class OSINTWorker(QObject):
    log_signal  = pyqtSignal(str, str)
    done_signal = pyqtSignal()

    def __init__(self, query: str, input_type: str, extended: bool,
                 chained: bool = False, config=None):
        super().__init__()
        self.query         = query.strip()
        self.input_type    = input_type
        self.extended      = extended
        self.chained       = chained
        self.config        = config if config is not None else ConfigManager()
        self._running      = True
        self._found_emails: list[str] = []
        self._found_ips:    list[str] = []

    def stop(self): self._running = False

    # ── Log helpers ───────────────────────────────────────────────────────────
    def _log(self, msg: str, col: str = COL_INFO):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_signal.emit(f"[{ts}]  {msg}", col)

    def _head(self, t: str):
        self._log("", COL_INFO)
        self._log(f"══  {t}  {'═' * max(0, 50 - len(t))}", COL_HEAD)

    def _ok(self,    m: str): self._log(f"  ✓  {m}", COL_OK)
    def _warn(self,  m: str): self._log(f"  ⚠  {m}", COL_WARN)
    def _err(self,   m: str): self._log(f"  ✗  {m}", COL_ERR)
    def _info(self,  m: str): self._log(f"  ·  {m}", COL_INFO)
    def _chain(self, m: str): self._log(f"  ⛓  {m}", COL_CHAIN)
    def _manu(self,  m: str): self._log(f"  👁  {m}", COL_MANU)

    # ── Entry point ───────────────────────────────────────────────────────────
    def _dbg(self, msg: str):
        """Write debug checkpoint to file — survives crashes that kill the process."""
        try:
            dbg_path = APP_DATA_DIR / "osint_crash_debug.txt"
            with open(dbg_path, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().strftime('%H:%M:%S.%f')} [{self.input_type}] {msg}\n")
                f.flush()
                import os; os.fsync(f.fileno())
        except Exception:
            pass

    def run(self):
        q, itype = self.query, self.input_type
        self._dbg(f"run() START query={q!r}")
        if self.chained:
            self._chain(f"CHAINED → {itype}: {q}")
        else:
            self._head(f"{APP_NAME}  v{VERSION}")
            self._info(f"TARGET : {q}")
            self._info(f"TYPE   : {itype}")
            self._info(f"MODE   : {'Extended' if self.extended else 'Curated'}")
            self._info(f"TIME   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        self._dbg("_build_tasks()")
        tasks = self._build_tasks(q, itype)
        self._dbg(f"tasks built: {[name for name, _ in tasks]}")

        # Run tasks SEQUENTIALLY for Phone to avoid thread-related crashes
        # All other types use thread pool
        if itype == "Phone":
            self._dbg("Phone: running tasks sequentially")
            for name, fn in tasks:
                if not self._running:
                    break
                self._dbg(f"Phone task START: {name}")
                try:
                    fn()
                except Exception as e:
                    self._err(f"{name} crashed: {e}")
                self._dbg(f"Phone task DONE: {name}")
        else:
            self._dbg("running tasks sequentially")
            for name, fn in tasks:
                if not self._running:
                    break
                self._dbg(f"task START: {name}")
                try:
                    fn()
                except Exception as e:
                    self._err(f"{name} crashed: {e}")
                self._dbg(f"task DONE: {name}")

        self._dbg("chaining emails/IPs")
        # Chain discovered emails
        for email in self._found_emails:
            if not self._running:
                break
            self._chain(f"Auto-scanning discovered email: {email}")
            sub = OSINTWorker(email, "Email", self.extended, chained=True,
                              config=self.config)
            sub.log_signal.connect(self.log_signal)
            sub._email_analysis(email)

        # Chain discovered IPs
        for ip in self._found_ips:
            if not self._running:
                break
            self._chain(f"Auto-scanning discovered IP: {ip}")
            sub = OSINTWorker(ip, "IP Address", self.extended, chained=True,
                              config=self.config)
            sub.log_signal.connect(self.log_signal)
            sub._ip_geo(ip)

        self._dbg("run() COMPLETE")
        if not self.chained:
            self._head("SCAN COMPLETE")
        self.done_signal.emit()

    def _build_tasks(self, q: str, itype: str) -> list:
        if itype == "Name":
            return [
                ("Name Variants",   lambda: self._name_variants(q)),
                ("Google Dorks",    lambda: self._google_dorks(q, itype)),
                # theHarvester not run for names — it expects a domain/email, not a person's name
            ]
        if itype == "Email":
            domain = q.split("@")[1] if "@" in q else q
            return [
                ("Email Analysis",  lambda: self._email_analysis(q)),
                ("DNS/MX",          lambda: self._dns_lookup(domain)),
                ("Google Dorks",    lambda: self._google_dorks(q, itype)),
                ("Paste Search",    lambda: self._paste_search(q)),
                ("theHarvester",    lambda: self._harvester(q)),
            ]
        if itype == "Phone":
            return [
                ("Phone Analysis",  lambda: self._phone_analysis(q)),
                ("Google Dorks",    lambda: self._google_dorks(q, itype)),
            ]
        if itype == "Username":
            return [
                ("Username Enum",   lambda: self._username_enum(q, self.extended, enrich=True)),
                ("Google Dorks",    lambda: self._google_dorks(q, itype)),
                ("Paste Search",    lambda: self._paste_search(q)),
                ("Wayback Machine", lambda: self._wayback(q)),
            ]
        if itype == "IP Address":
            return [
                ("IP Geolocation",  lambda: self._ip_geo(q)),
                ("WHOIS",           lambda: self._whois_lookup(q)),
                ("Reverse DNS",     lambda: self._reverse_dns(q)),
                ("Shodan Public",   lambda: self._shodan(q)),
                ("Google Dorks",    lambda: self._google_dorks(q, itype)),
            ]
        if itype == "Domain":
            return [
                ("Domain→IP",       lambda: self._domain_to_ip(q)),
                ("WHOIS",           lambda: self._whois_lookup(q)),
                ("DNS Enum",        lambda: self._dns_lookup(q)),
                ("crt.sh",          lambda: self._crtsh(q)),
                ("Wayback Machine", lambda: self._wayback(q)),
                ("Shodan Public",   lambda: self._shodan(q)),
                ("SecurityTrails",  lambda: self._securitytrails(q)),
                ("VirusTotal",      lambda: self._virustotal_domain(q)),
                ("Google Dorks",    lambda: self._google_dorks(q, itype)),
                ("theHarvester",    lambda: self._harvester(q)),
                ("Paste Search",    lambda: self._paste_search(q)),
            ]
        return []

    # ── Username Enumeration ──────────────────────────────────────────────────
    def _username_enum(self, username: str, extended: bool, enrich: bool = False):
        sites = EXTENDED_SITES if extended else CURATED_SITES
        self._dbg("ENTER _username_enum")
        self._head(f"USERNAME ENUMERATION")

        # Manual-check sites — logged with links, not probed
        self._info("Manual-check sites (login wall / JS-rendered — click to verify):")
        for name, url_tmpl in MANUAL_SITES.items():
            url = url_tmpl.format(username)
            self._log(f"  [MANUAL] {name:<16} {url}", COL_MANU)

        confirmed = []

        # ── API-confirmed platforms (reliable 404, no scraping) ───────────────
        self._head("API-CONFIRMED CHECKS")

        try:
            d = http_get(f"https://api.github.com/users/{username}", timeout=6, json_resp=True)
            if d and d.get("login") and d.get("message") != "Not Found":
                self._ok(f"[API] GitHub         https://github.com/{username}")
                confirmed.append(("GitHub", f"https://github.com/{username}", d))
        except Exception:
            pass

        try:
            d = http_get(f"https://www.reddit.com/user/{username}/about.json", timeout=6, json_resp=True)
            if d and "data" in d and d.get("error") != 404:
                self._ok(f"[API] Reddit         https://www.reddit.com/user/{username}")
                confirmed.append(("Reddit", f"https://www.reddit.com/user/{username}", d))
        except Exception:
            pass

        try:
            d = http_get(f"https://hacker-news.firebaseio.com/v0/user/{username}.json", timeout=6, json_resp=True)
            if d and isinstance(d, dict) and d.get("id"):
                self._ok(f"[API] HackerNews     https://news.ycombinator.com/user?id={username}")
                confirmed.append(("HackerNews", f"https://news.ycombinator.com/user?id={username}", d))
        except Exception:
            pass

        try:
            d = http_get(f"https://mastodon.social/api/v1/accounts/lookup?acct={username}", timeout=6, json_resp=True)
            if d and d.get("id"):
                self._ok(f"[API] Mastodon       https://mastodon.social/@{username}")
                confirmed.append(("Mastodon", f"https://mastodon.social/@{username}", d))
        except Exception:
            pass

        # ── Search links for all other platforms ──────────────────────────────
        self._head("PLATFORM SEARCH LINKS")
        self._info("Click to check each platform manually:")
        for name, (url_tmpl, _) in sites.items():
            if name in ("GitHub", "Reddit", "HackerNews", "Mastodon"):
                continue  # already checked via API
            url = url_tmpl.format(username)
            self._info(f"  {name:<18} {url}")

        self._info(f"Enumeration complete — {len(confirmed)} API-confirmed profile(s)")

        # Social enrichment for confirmed profiles
        if enrich and confirmed:
            self._head("SOCIAL PROFILE ENRICHMENT")
            for platform, url, data in confirmed:
                if platform in SOCIAL_ENRICH_PLATFORMS:
                    try:
                        self._enrich_social(platform, username, data)
                    except Exception as e:
                        self._warn(f"{platform} enrichment error: {e}")
    # ── Social Enrichment ─────────────────────────────────────────────────────
    def _enrich_social(self, platform: str, username: str, data):
        self._info(f"── {platform} profile detail ──")
        self._dbg("ENTER _enrich_social")

        if platform == "GitHub":
            # data is already the API JSON dict
            fields = [
                ("Name",       data.get("name")),
                ("Bio",        data.get("bio")),
                ("Company",    data.get("company")),
                ("Location",   data.get("location")),
                ("Blog",       data.get("blog")),
                ("Email",      data.get("email")),
                ("Followers",  data.get("followers")),
                ("Following",  data.get("following")),
                ("Repos",      data.get("public_repos")),
                ("Gists",      data.get("public_gists")),
                ("Twitter",    data.get("twitter_username")),
                ("Created",    data.get("created_at")),
                ("Updated",    data.get("updated_at")),
                ("Hireable",   data.get("hireable")),
                ("Site Admin", data.get("site_admin")),
            ]
            for label, val in fields:
                if val is not None and val not in ("", False):
                    self._ok(f"  GH/{label:<14} {val}")
            email = data.get("email")
            if email and email not in self._found_emails:
                self._found_emails.append(email)

        elif platform == "Reddit":
            d = data.get("data", {}) if isinstance(data, dict) else {}
            created = ""
            if d.get("created_utc"):
                created = datetime.utcfromtimestamp(d["created_utc"]).strftime("%Y-%m-%d")
            fields = [
                ("Name",           d.get("name")),
                ("Comment karma",  d.get("comment_karma")),
                ("Link karma",     d.get("link_karma")),
                ("Total karma",    d.get("total_karma")),
                ("Verified email", d.get("has_verified_email")),
                ("Gold",           d.get("is_gold")),
                ("Moderator",      d.get("is_mod")),
                ("Created",        created),
            ]
            for label, val in fields:
                if val is not None and val not in ("", False):
                    self._ok(f"  RD/{label:<16} {val}")

        elif platform == "HackerNews":
            if isinstance(data, dict):
                created = ""
                if data.get("created"):
                    created = datetime.utcfromtimestamp(data["created"]).strftime("%Y-%m-%d")
                about = re.sub(r"<[^>]+>", "", data.get("about", "")) if data.get("about") else ""
                fields = [
                    ("Karma",   data.get("karma")),
                    ("About",   about),
                    ("Created", created),
                    ("Delay",   data.get("delay")),
                ]
                for label, val in fields:
                    if val is not None and val != "":
                        self._ok(f"  HN/{label:<17} {val}")

        elif platform == "Steam":
            # data here is the scraped body string
            body = data if isinstance(data, str) else ""
            patterns = [
                ("Display name",  r'class="actual_persona_name"[^>]*>([^<]+)<'),
                ("Level",         r'friendPlayerLevelNum">(\d+)<'),
                ("Member since",  r'Member since\s+([A-Za-z]+ \d{1,2}, \d{4})'),
            ]
            for label, pat in patterns:
                m = re.search(pat, body)
                if m:
                    self._ok(f"  ST/{label:<14} {m.group(1).strip()}")

        elif platform == "Mastodon":
            try:
                d = http_get(
                    f"https://mastodon.social/api/v1/accounts/lookup?acct={username}",
                    timeout=8, json_resp=True
                )
                fields = [
                    ("Display name", d.get("display_name")),
                    ("Bio",          re.sub(r"<[^>]+>", "", d.get("note", ""))),
                    ("Followers",    d.get("followers_count")),
                    ("Following",    d.get("following_count")),
                    ("Posts",        d.get("statuses_count")),
                    ("Joined",       (d.get("created_at") or "")[:10]),
                    ("Bot",          d.get("bot")),
                ]
                for label, val in fields:
                    if val is not None and val not in ("", False):
                        self._ok(f"  MD/{label:<14} {val}")
            except Exception as e:
                self._warn(f"Mastodon API: {e}")

    # ── Name Variants ─────────────────────────────────────────────────────────
    def _name_variants(self, name: str):
        self._head(f"NAME ANALYSIS: {name}")
        self._dbg("ENTER _name_variants")
        variants = generate_name_variants(name)
        self._info(f"Generated {len(variants)} username variants:")
        for v in variants:
            self._info(f"  {v}")

        # For name searches: provide search links per variant rather than
        # HTTP probing (probing 16 variants × 32 sites sequentially causes
        # freezes and crashes on Windows)
        self._head("VARIANT SEARCH LINKS")
        self._info("Search these username variants across platforms:")
        for v in variants:
            q = urllib.parse.quote_plus(v)
            self._info(f"  {v}:")
            self._info(f"    Google   → https://www.google.com/search?q=%22{q}%22")
            self._info(f"    GitHub   → https://api.github.com/users/{v}")
            self._info(f"    Reddit   → https://www.reddit.com/user/{v}/about.json")


    # ── Google Dorks ──────────────────────────────────────────────────────────
    def _google_dorks(self, query: str, itype: str):
        self._head("GOOGLE DORK LINKS")
        self._dbg("ENTER _google_dorks")
        q  = urllib.parse.quote_plus(f'"{query}"')
        qr = urllib.parse.quote_plus(query)

        dork_map = {
            "Name": [
                ("Full name search",  f"https://www.google.com/search?q={q}"),
                ("Social profiles",   f"https://www.google.com/search?q={q}+site:linkedin.com+OR+site:twitter.com+OR+site:facebook.com"),
                ("News mentions",     f"https://www.google.com/search?q={q}&tbm=nws"),
                ("Images",            f"https://www.google.com/search?q={q}&tbm=isch"),
                ("Documents/PDFs",    f"https://www.google.com/search?q={q}+filetype:pdf+OR+filetype:doc"),
                ("Public records",    f"https://www.google.com/search?q={q}+%22address%22+OR+%22phone%22+OR+%22email%22"),
                ("Court records",     f"https://www.google.com/search?q={q}+site:courtlistener.com"),
            ],
            "Email": [
                ("Email exact",       f"https://www.google.com/search?q={q}"),
                ("Breach mentions",   f"https://www.google.com/search?q={q}+%22breach%22+OR+%22leak%22"),
                ("Social accounts",   f"https://www.google.com/search?q={q}+site:linkedin.com+OR+site:twitter.com"),
                ("Pastebin leaks",    f"https://www.google.com/search?q={q}+site:pastebin.com"),
                ("GitHub leaks",      f"https://www.google.com/search?q={q}+site:github.com"),
                ("Forum mentions",    f"https://www.google.com/search?q={q}+site:reddit.com"),
            ],
            "Phone": [
                ("Phone search",      f"https://www.google.com/search?q={q}"),
                ("Owner lookup",      f"https://www.google.com/search?q={q}+%22owner%22+OR+%22name%22"),
                ("Business listings", f"https://www.google.com/search?q={q}+site:yellowpages.com+OR+site:yelp.com"),
                ("Spam reports",      f"https://www.google.com/search?q={q}+site:800notes.com+OR+site:whocallsme.com"),
            ],
            "Username": [
                ("Username exact",    f"https://www.google.com/search?q={q}"),
                ("Forum activity",    f"https://www.google.com/search?q={q}+site:reddit.com"),
                ("Social profiles",   f"https://www.google.com/search?q={q}+site:twitter.com+OR+site:instagram.com"),
                ("GitHub activity",   f"https://www.google.com/search?q={q}+site:github.com"),
                ("Paste sites",       f"https://www.google.com/search?q={q}+site:pastebin.com+OR+site:ghostbin.com"),
                ("Images",            f"https://www.google.com/search?q={q}&tbm=isch"),
            ],
        }
        ip_domain_dorks = [
            ("IP/Domain search",  f"https://www.google.com/search?q={qr}"),
            ("Shodan",            f"https://www.shodan.io/search?query={qr}"),
            ("Censys",            f"https://search.censys.io/search?resource=hosts&q={qr}"),
            ("VirusTotal",        f"https://www.virustotal.com/gui/domain/{qr}"),
            ("SecurityTrails",    f"https://securitytrails.com/domain/{qr}/history/a"),
            ("BuiltWith",         f"https://builtwith.com/{qr}"),
            ("crt.sh certs",      f"https://crt.sh/?q=%.{qr}"),
        ]

        dorks = dork_map.get(itype, ip_domain_dorks if itype in ("IP Address","Domain") else [])
        for label, url in dorks:
            self._info(f"{label}:")
            self._info(f"    → {url}")

        self._info(f"{len(dorks)} dork link(s) — opening in browser...")
        for _, url in dorks:
            if not self._running:
                break

    # ── theHarvester ──────────────────────────────────────────────────────────
    def _harvester(self, query: str):
        self._head("theHARVESTER")
        self._dbg("ENTER _harvester")

        # NOTE: The PyPI package 'theHarvester' (v0.0.1) is a stub with no executable.
        # The real tool must be installed from https://github.com/laramies/theHarvester
        # or via: apt install theharvester (Kali/Debian)
        # On Windows: clone the repo and run theHarvester.py directly.

        exe = self._find_harvester_exe()
        if not exe:
            self._warn("theHarvester executable not found — skipping")
            self._info("The PyPI package (pip install theHarvester) is a stub — it has no executable.")
            self._info("Install the real tool:")
            self._info("  Kali/Debian : sudo apt install theharvester")
            self._info("  From source : git clone https://github.com/laramies/theHarvester")
            self._info("                cd theHarvester && pip install -r requirements/base.txt")
            self._info("                python theHarvester.py -h")
            return

        try:
            # Free sources verified working in theHarvester 4.11.x — no API keys needed
            # Removed: google, bing, vhost, threatminer, subdomainfinder (unsupported in 4.11)
            free_sources = ",".join([
                "anubis", "baidu", "brave", "certspotter", "crtsh",
                "dnsdumpster", "duckduckgo", "hackertarget", "otx",
                "rapiddns", "sitedossier", "urlscan",
            ])
            cmd = exe + ["-d", query, "-b", free_sources, "-l", "200"]
            self._ok(f"Running: {' '.join(cmd)}")
            kwargs = dict(capture_output=True, text=True, timeout=300,
                          encoding="utf-8", errors="replace")
            if sys.platform == "win32":
                kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            proc = subprocess.run(cmd, **kwargs)
            output = proc.stdout + proc.stderr
            for line in output.splitlines():
                if line.strip():
                    self._info(line.strip())

            # Strip the theHarvester ASCII banner before extracting emails/IPs
            # The banner contains the author's email which is not a real find
            # Banner ends after the last line of asterisks (***...***) in the header
            banner_end = output.find("[*]")
            if banner_end == -1:
                banner_end = output.find("theHarvester 4")
                if banner_end >= 0:
                    # Skip to end of banner block (next blank line after version)
                    banner_end = output.find("\n\n", banner_end)
            results_output = output[banner_end:] if banner_end > 0 else output

            for e in extract_emails(results_output):
                if e not in self._found_emails:
                    self._chain(f"Discovered email: {e}")
                    self._found_emails.append(e)
            for ip in extract_ips(results_output):
                if ip not in self._found_ips:
                    self._chain(f"Discovered IP: {ip}")
                    self._found_ips.append(ip)
        except subprocess.TimeoutExpired:
            self._warn("theHarvester timed out after 300s")
        except Exception as e:
            self._err(f"theHarvester error: {e}")

    def _find_harvester_exe(self) -> list | None:
        """
        Returns a command prefix list to invoke theHarvester, or None if not found.
        Searches in priority order:
          1. Venv Scripts folder (same venv as sys.executable)
          2. which/where in PATH
          3. Common Windows locations (APPDATA Scripts, Program Files pythons)
          4. Common Unix locations
          5. python -m theHarvester with multiple interpreters
          6. theHarvester.py script directly (GitHub clone)
        Rejects the PyPI stub (v0.0.1 / no module named / no usage output).
        """
        import os, glob as _glob

        candidates = []  # list of (cmd_parts, label)

        # ── 1. Venv Scripts folder — same env as sys.executable ──────────────
        venv_scripts = Path(sys.executable).parent
        for name in ["theHarvester.exe", "theHarvester"]:
            p = venv_scripts / name
            if p.exists():
                candidates.insert(0, ([str(p)], str(p)))

        # ── 2. which/where in PATH ────────────────────────────────────────────
        which_cmd = "where" if sys.platform == "win32" else "which"
        for name in ["theHarvester", "theharvester"]:
            try:
                which_kwargs = dict(capture_output=True, text=True, timeout=5,
                                   encoding="utf-8", errors="replace")
                if sys.platform == "win32":
                    which_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
                r = subprocess.run([which_cmd, name], **which_kwargs)
                for line in r.stdout.strip().splitlines():
                    line = line.strip()
                    if line and line not in [c[0] for c, _ in candidates]:
                        candidates.append(([line], line))
            except Exception:
                pass
            candidates.append(([name], name))

        # ── 3. Windows-specific ───────────────────────────────────────────────
        if sys.platform == "win32":
            # APPDATA user Scripts (pip install --user)
            appdata = os.environ.get("APPDATA", "")
            localappdata = os.environ.get("LOCALAPPDATA", "")
            for base in filter(None, [appdata, localappdata]):
                for scripts_dir in _glob.glob(
                    os.path.join(base, "Python", "Python3*", "Scripts")
                ):
                    for name in ["theHarvester.exe", "theHarvester"]:
                        p = os.path.join(scripts_dir, name)
                        if os.path.exists(p):
                            candidates.insert(0, ([p], p))
            # All python.exe in Program Files — try -m theHarvester
            for prog_base in [r"C:\Program Files", r"C:\Program Files (x86)"]:
                for py_dir in _glob.glob(os.path.join(prog_base, "Python3*")):
                    py_exe = os.path.join(py_dir, "python.exe")
                    if os.path.exists(py_exe):
                        candidates.append(
                            ([py_exe, "-m", "theHarvester"],
                             f"{py_exe} -m theHarvester")
                        )
            # GitHub clone locations
            for p in [
                r"C:\theHarvester\theHarvester.py",
                r"C:\Tools\theHarvester\theHarvester.py",
                os.path.join(os.path.expanduser("~"), "theHarvester", "theHarvester.py"),
                os.path.join(os.path.expanduser("~"), "tools", "theHarvester", "theHarvester.py"),
            ]:
                if Path(p).exists():
                    candidates.append(([sys.executable, p], p))

        # ── 4. Unix locations ─────────────────────────────────────────────────
        else:
            home = Path.home()
            for p in [
                Path("/usr/bin/theharvester"),
                Path("/usr/bin/theHarvester"),
                Path("/usr/local/bin/theHarvester"),
                Path("/opt/homebrew/bin/theHarvester"),
                home / ".local" / "bin" / "theHarvester",
                home / ".local" / "bin" / "theharvester",
                home / "theHarvester" / "theHarvester.py",
                home / "tools" / "theHarvester" / "theHarvester.py",
            ]:
                if p.exists():
                    candidates.insert(0, ([str(p)], str(p)))

        # ── 5. python -m theHarvester with multiple interpreters ──────────────
        for py in list(dict.fromkeys(filter(None, [
            sys.executable,
            "python3", "python",
            "python3.14", "python3.13", "python3.12", "python3.11", "python3.10",
        ]))):
            candidates.append(([py, "-m", "theHarvester"], f"{py} -m theHarvester"))

        # ── Deduplicate ───────────────────────────────────────────────────────
        seen, unique = set(), []
        for cmd_parts, label in candidates:
            key = tuple(cmd_parts)
            if key not in seen:
                seen.add(key)
                unique.append((cmd_parts, label))

        # ── Probe each candidate ──────────────────────────────────────────────
        for cmd_parts, label in unique:
            try:
                run_kwargs = dict(capture_output=True, text=True, timeout=10,
                                  encoding="utf-8", errors="replace")
                if sys.platform == "win32":
                    run_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
                r = subprocess.run(cmd_parts + ["--help"], **run_kwargs)
                combined = (r.stdout + r.stderr).lower()
                # Hard rejects — stub package or missing module
                if "no module named" in combined:
                    continue
                if "0.0.1" in combined and "usage" not in combined:
                    continue
                # Must show actual usage
                if "usage" in combined or "theharvester" in combined:
                    self._ok(f"Found theHarvester: {label}")
                    return cmd_parts
            except FileNotFoundError:
                continue
            except Exception:
                continue

        return None
    # ── Email Analysis ────────────────────────────────────────────────────────
    def _email_analysis(self, email: str):
        self._head(f"EMAIL ANALYSIS: {email}")
        self._dbg("ENTER _email_analysis")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
            self._warn("Not a valid email address")
            return
        local, domain = email.split("@", 1)
        self._info(f"Local part : {local}")
        self._info(f"Domain     : {domain}")
        providers = {
            "gmail.com": "Google Gmail", "yahoo.com": "Yahoo Mail",
            "hotmail.com": "Microsoft Hotmail", "outlook.com": "Microsoft Outlook",
            "protonmail.com": "ProtonMail (encrypted)", "proton.me": "ProtonMail (encrypted)",
            "tutanota.com": "Tutanota (encrypted)", "icloud.com": "Apple iCloud",
        }
        prov = providers.get(domain.lower())
        if prov:
            self._ok(f"Provider   : {prov}")
        else:
            self._info("Provider   : Unknown / custom domain")
        if "+" in local:
            self._info(f"Plus addr  : base = {local.split('+')[0]}@{domain}")
        h   = hashlib.md5(email.strip().lower().encode()).hexdigest()
        gurl = f"https://www.gravatar.com/avatar/{h}?d=404"
        self._info(f"Gravatar   : {gurl}")
        try:
            req = urllib.request.Request(gurl, headers={"User-Agent": rand_ua()})
            with urllib.request.urlopen(req, timeout=6) as resp:
                if resp.status == 200:
                    self._ok(f"Gravatar EXISTS → https://www.gravatar.com/{h}")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self._info("No Gravatar profile")
        except Exception:
            self._warn("Gravatar check failed")

        # ── Hunter.io ─────────────────────────────────────────────────────────
        hunter_key = self.config.key("hunter")
        if hunter_key:
            self._head(f"HUNTER.IO: {email}")
            try:
                d = _api_get(f"https://api.hunter.io/v2/email-verifier?email={urllib.parse.quote(email)}&api_key={hunter_key}")
                if d and "data" in d:
                    dd = d["data"]
                    for label, val in [
                        ("Status",     dd.get("status")),
                        ("Result",     dd.get("result")),
                        ("Score",      dd.get("score")),
                        ("Disposable", dd.get("disposable")),
                        ("Webmail",    dd.get("webmail")),
                        ("MX records", dd.get("mx_records")),
                        ("SMTP valid", dd.get("smtp_check")),
                        ("Accept all", dd.get("accept_all")),
                        ("Block",      dd.get("block")),
                    ]:
                        if val is not None:
                            self._ok(f"  {label:<14} {val}")
            except Exception as e:
                self._warn(f"Hunter.io error: {e}")
        else:
            self._info("Hunter.io: no key (Settings → API Keys)")

        # ── AbstractAPI Email ──────────────────────────────────────────────────
        ab_key = self.config.key("abstractapi_email")
        if ab_key:
            self._head(f"ABSTRACTAPI EMAIL: {email}")
            try:
                d = _api_get(f"https://emailvalidation.abstractapi.com/v1/?api_key={ab_key}&email={urllib.parse.quote(email)}")
                if d:
                    for label, val in [
                        ("Deliverability", d.get("deliverability")),
                        ("Quality score",  d.get("quality_score")),
                        ("Disposable",     d.get("is_disposable_email", {}).get("value")),
                        ("Free email",     d.get("is_free_email", {}).get("value")),
                        ("Role email",     d.get("is_role_email", {}).get("value")),
                        ("MX found",       d.get("is_mx_found", {}).get("value")),
                        ("SMTP valid",     d.get("is_smtp_valid", {}).get("value")),
                        ("Autocorrect",    d.get("autocorrect")),
                    ]:
                        if val is not None and val != "":
                            self._ok(f"  {label:<18} {val}")
            except Exception as e:
                self._warn(f"AbstractAPI Email error: {e}")
        else:
            self._info("AbstractAPI Email: no key (Settings → API Keys)")

        # ── HaveIBeenPwned ────────────────────────────────────────────────────
        hibp_key = self.config.key("hibp")
        if hibp_key:
            self._head(f"HAVEIBEENPWNED: {email}")
            try:
                req = urllib.request.Request(
                    f"https://haveibeenpwned.com/api/v3/breachedaccount/{urllib.parse.quote(email)}?truncateResponse=false",
                    headers={"hibp-api-key": hibp_key, "User-Agent": "OSINTofDeath/4.0"}
                )
                try:
                    with urllib.request.urlopen(req, timeout=10) as r:
                        breaches = json.loads(r.read().decode())
                        self._err(f"FOUND IN {len(breaches)} BREACH(ES):")
                        for b in breaches:
                            exposed = ", ".join(b.get("DataClasses", []))
                            self._warn(f"  · {b.get('Name','?')} ({b.get('BreachDate','?')}) — {exposed}")
                except urllib.error.HTTPError as e:
                    if e.code == 404:
                        self._ok("Not found in any known breaches")
                    elif e.code == 401:
                        self._warn("HIBP: Invalid API key")
                    else:
                        self._warn(f"HIBP HTTP {e.code}")
            except Exception as e:
                self._warn(f"HIBP error: {e}")
        else:
            self._info("HaveIBeenPwned: no key (Settings → API Keys)")

    # ── DNS Lookup ────────────────────────────────────────────────────────────
    def _dns_lookup(self, domain: str):
        self._head(f"DNS ENUMERATION: {domain}")
        self._dbg("ENTER _dns_lookup")

        def _nslookup(query: str, rtype: str) -> list:
            try:
                kw = dict(capture_output=True, text=True, timeout=8,
                          encoding="utf-8", errors="replace")
                if sys.platform == "win32":
                    kw["creationflags"] = subprocess.CREATE_NO_WINDOW
                r = subprocess.run(["nslookup", f"-type={rtype}", query], **kw)
                lines = (r.stdout + r.stderr).splitlines()
                results = []
                private = re.compile(
                    r"^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|127\.|0\.)"
                )
                skip_keywords = [
                    "server:", "address:", "unknown", "can't find",
                    "non-existent", "***", "default server", "unktimed",
                ]
                for line in lines:
                    line = line.strip()
                    if not line: continue
                    low = line.lower()
                    if any(k in low for k in skip_keywords): continue
                    for part in line.split():
                        part = part.rstrip(".")
                        if (part and "." in part
                                and part != query
                                and not part.startswith("-")
                                and not private.match(part)
                                and len(part) > 3):
                            results.append(part)
                return list(dict.fromkeys(results))[:5]
            except Exception:
                return []

        # A record via socket
        try:
            for info in socket.getaddrinfo(domain, None, socket.AF_INET):
                ip = info[4][0]
                self._ok(f"A      → {ip}")
                if ip not in self._found_ips:
                    self._found_ips.append(ip)
        except Exception as e:
            self._warn(f"A      → {e}")

        # AAAA via socket
        try:
            for info in socket.getaddrinfo(domain, None, socket.AF_INET6):
                self._ok(f"AAAA   → {info[4][0]}")
        except Exception:
            pass

        # MX, NS, TXT via nslookup
        for rtype in ["MX", "NS", "TXT"]:
            results = _nslookup(domain, rtype)
            if results:
                for r in results:
                    self._ok(f"{rtype:<6} → {r}")
            else:
                self._info(f"{rtype:<6} → No records")

        # Subdomain brute-force via socket
        self._info("Checking common subdomains...")
        for sub in ["www","mail","ftp","vpn","remote","admin","api",
                    "dev","staging","blog","shop","portal","git","ns1","ns2"]:
            try:
                ip = socket.gethostbyname(f"{sub}.{domain}")
                self._ok(f"  {sub}.{domain} → {ip}")
                if ip not in self._found_ips:
                    self._found_ips.append(ip)
            except Exception:
                pass
    # ── Phone Analysis ────────────────────────────────────────────────────────
    def _phone_analysis(self, phone: str):
        self._dbg("ENTER _phone_analysis")
        def _ck(msg):
            self._dbg(f"_phone_analysis: {msg}")

        _ck("START")
        self._head(f"PHONE ANALYSIS: {phone}")
        _ck("after _head")
        try:
            parsed = phonenumbers.parse(phone, None)
            _ck("after parse")
        except phonenumbers.phonenumberutil.NumberParseException as e:
            self._err(f"Could not parse: {e}")
            self._info("Tip: Include country code, e.g. +1 555 123 4567")
            return

        type_map = {0:"FIXED_LINE",1:"MOBILE",2:"FIXED_LINE_OR_MOBILE",
                    3:"TOLL_FREE",4:"PREMIUM_RATE",5:"SHARED_COST",
                    6:"VOIP",7:"PERSONAL_NUMBER",8:"PAGER",9:"UAN",
                    10:"VOICEMAIL",-1:"UNKNOWN"}

        _ck("before is_valid")
        is_valid  = phonenumbers.is_valid_number(parsed)
        _ck("before e164")
        e164      = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
        _ck("before intl")
        intl      = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
        _ck("before natl")
        natl      = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)
        _ck("before region/geocoder")
        region    = geocoder.description_for_number(parsed, "en")
        _ck("before carrier")
        carr      = carrier.name_for_number(parsed, "en") or "Unknown"
        _ck("before timezone")
        timezones = ", ".join(pn_timezone.time_zones_for_number(parsed))
        _ck("before number_type")
        line_type = type_map.get(phonenumbers.number_type(parsed), "UNKNOWN")
        _ck("after all phone data")

        self._ok  (f"Valid          : {is_valid}")
        self._ok  (f"E.164          : {e164}")
        self._ok  (f"International  : {intl}")
        self._ok  (f"National       : {natl}")
        self._ok  (f"Country code   : +{parsed.country_code}")
        self._ok  (f"Region         : {region}")
        self._ok  (f"Carrier        : {carr}")
        self._info(f"Timezone(s)    : {timezones}")
        self._info(f"Line type      : {line_type}")

        # ── Format variants ───────────────────────────────────────────────────
        self._head("PHONE FORMAT VARIANTS")
        raw_digits = re.sub(r"\D", "", phone)
        for v in list(dict.fromkeys([e164, intl, natl, raw_digits,
                                     intl.replace(" ", "-"), intl.replace(" ", ".")])):
            self._info(f"  {v}")

        # ── Lookup links ──────────────────────────────────────────────────────
        self._head("PHONE LOOKUP LINKS")
        qe = urllib.parse.quote_plus(e164)
        qr = urllib.parse.quote_plus(raw_digits)
        links = [
            ("Truecaller",    f"https://www.truecaller.com/search/us/{qr}"),
            ("WhitePages",    f"https://www.whitepages.com/phone/{qr}"),
            ("Spokeo",        f"https://www.spokeo.com/search?q={qe}"),
            ("800notes",      f"https://800notes.com/Phone.aspx/{qr}"),
            ("WhoCallsMe",    f"https://whocallsme.com/Phone-Number.aspx/{qr}"),
            ("ShouldIAnswer", f"https://www.shouldianswer.com/phone-number/{qr}"),
            ("CallerSmart",   f"https://www.callersmart.com/phone/{qr}"),
            ("NumLookup",     f"https://www.numlookup.com/?number={qe}"),
            ("Google",        f"https://www.google.com/search?q=%22{urllib.parse.quote_plus(intl)}%22"),
            ("Telegram",      f"https://t.me/{qr}"),
        ]
        for label, url in links:
            self._info(f"  {label:<20} {url}")
        for _, url in links:
            if not self._running:
                break

        # ── Paste/breach dorks ────────────────────────────────────────────────
        self._head("PHONE BREACH / PASTE SEARCH")
        for variant in [e164, intl, raw_digits]:
            qv  = urllib.parse.quote_plus(f'"{variant}"')
            url = f"https://www.google.com/search?q={qv}+site:pastebin.com+OR+site:ghostbin.com"
            self._info(f"  ({variant}): {url}")
            if not self._running:
                break

        # ── NumVerify API ─────────────────────────────────────────────────────
        nv_key = self.config.key("numverify")
        if nv_key:
            self._head("NUMVERIFY API")
            try:
                d = _api_get(f"http://apilayer.net/api/validate?access_key={nv_key}&number={urllib.parse.quote(e164)}&format=1")
                if d and d.get("valid") is not None:
                    for label, val in [
                        ("Valid",        d.get("valid")),
                        ("Location",     d.get("location")),
                        ("Carrier",      d.get("carrier")),
                        ("Line type",    d.get("line_type")),
                        ("Country",      d.get("country_name")),
                        ("Intl format",  d.get("international_format")),
                    ]:
                        if val is not None and val != "":
                            self._ok(f"  {label:<14} {val}")
                elif d and d.get("error"):
                    self._warn(f"NumVerify: {d['error'].get('info','error')}")
            except Exception as e:
                self._warn(f"NumVerify error: {e}")
        else:
            self._info("NumVerify: no key (Settings → API Keys)")

        # ── AbstractAPI Phone ─────────────────────────────────────────────────
        ab_key = self.config.key("abstractapi_phone")
        if ab_key:
            self._head("ABSTRACTAPI PHONE")
            try:
                d = _api_get(f"https://phonevalidation.abstractapi.com/v1/?api_key={ab_key}&phone={urllib.parse.quote(e164)}")
                if d:
                    for label, val in [
                        ("Valid",    d.get("valid")),
                        ("Country",  d.get("country", {}).get("name")),
                        ("Carrier",  d.get("carrier")),
                        ("Type",     d.get("type")),
                        ("E164",     d.get("format", {}).get("e164")),
                    ]:
                        if val is not None and val != "":
                            self._ok(f"  {label:<12} {val}")
            except Exception as e:
                self._warn(f"AbstractAPI Phone error: {e}")
        else:
            self._info("AbstractAPI Phone: no key (Settings → API Keys)")
    # ── IP Geolocation ────────────────────────────────────────────────────────
    def _ip_geo(self, ip: str):
        self._head(f"IP GEOLOCATION: {ip}")
        self._dbg("ENTER _ip_geo")
        try:
            data = http_get(
                f"http://ip-api.com/json/{ip}?fields=status,message,continent,"
                f"country,countryCode,region,regionName,city,district,zip,lat,lon,"
                f"timezone,isp,org,as,asname,reverse,mobile,proxy,hosting,query",
                timeout=10, json_resp=True
            )
            if data.get("status") == "fail":
                self._err(f"Lookup failed: {data.get('message')}")
                return
            for label, val in [
                ("IP",          data.get("query")),
                ("Continent",   data.get("continent")),
                ("Country",     f"{data.get('country')} ({data.get('countryCode')})"),
                ("Region",      f"{data.get('regionName')} ({data.get('region')})"),
                ("City",        data.get("city")),
                ("District",    data.get("district")),
                ("ZIP",         data.get("zip")),
                ("Coordinates", f"{data.get('lat')}, {data.get('lon')}"),
                ("Timezone",    data.get("timezone")),
                ("ISP",         data.get("isp")),
                ("Org",         data.get("org")),
                ("AS",          data.get("as")),
                ("AS Name",     data.get("asname")),
                ("Reverse DNS", data.get("reverse")),
                ("Mobile",      data.get("mobile")),
                ("Proxy/VPN",   data.get("proxy")),
                ("Hosting",     data.get("hosting")),
            ]:
                if val is not None and val != "":
                    self._ok(f"{label:<14} {val}")
            lat, lon = data.get("lat"), data.get("lon")
            if lat and lon:
                self._info(f"Maps → https://www.google.com/maps?q={lat},{lon}")
        except Exception as e:
            self._err(f"Geolocation error: {e}")

        # ── IPInfo API ────────────────────────────────────────────────────────
        ipinfo_key = self.config.key("ipinfo")
        if ipinfo_key:
            self._head(f"IPINFO API: {ip}")
            try:
                d = _api_get(f"https://ipinfo.io/{ip}?token={ipinfo_key}")
                if d and not d.get("error"):
                    for label, val in [
                        ("Hostname",  d.get("hostname")),
                        ("City",      d.get("city")),
                        ("Region",    d.get("region")),
                        ("Country",   d.get("country")),
                        ("Location",  d.get("loc")),
                        ("Org",       d.get("org")),
                        ("Postal",    d.get("postal")),
                        ("Timezone",  d.get("timezone")),
                        ("VPN/Proxy", d.get("privacy",{}).get("vpn") if isinstance(d.get("privacy"),dict) else None),
                        ("Tor",       d.get("privacy",{}).get("tor") if isinstance(d.get("privacy"),dict) else None),
                        ("Abuse email",d.get("abuse",{}).get("email") if isinstance(d.get("abuse"),dict) else None),
                    ]:
                        if val is not None and val != "":
                            self._ok(f"  {label:<14} {val}")
            except Exception as e:
                self._warn(f"IPInfo error: {e}")
        else:
            self._info("IPInfo API: no key configured")

        # ── AbuseIPDB ─────────────────────────────────────────────────────────
        abuse_key = self.config.key("abuseipdb")
        if abuse_key:
            self._head(f"ABUSEIPDB: {ip}")
            try:
                d = _api_get(
                    f"https://api.abuseipdb.com/api/v2/check?ipAddress={ip}&maxAgeInDays=90&verbose",
                    headers={"Key": abuse_key, "Accept": "application/json"}
                )
                if d and "data" in d:
                    dd = d["data"]
                    score = dd.get("abuseConfidenceScore", 0)
                    tag = COL_ERR if score > 50 else COL_WARN if score > 10 else COL_OK
                    self.log_signal.emit(
                        f"[{datetime.now().strftime('%H:%M:%S')}]    Abuse score    : {score}%", tag
                    )
                    for label, val in [
                        ("ISP",           dd.get("isp")),
                        ("Domain",        dd.get("domain")),
                        ("Country",       dd.get("countryCode")),
                        ("Usage type",    dd.get("usageType")),
                        ("Total reports", dd.get("totalReports")),
                        ("Last reported", dd.get("lastReportedAt")),
                        ("Is whitelisted",dd.get("isWhitelisted")),
                        ("Is Tor",        dd.get("isTor")),
                    ]:
                        if val is not None and val != "":
                            self._ok(f"  {label:<16} {val}")
            except Exception as e:
                self._warn(f"AbuseIPDB error: {e}")
        else:
            self._info("AbuseIPDB: no key configured")

        # ── Shodan API ────────────────────────────────────────────────────────
        shodan_key = self.config.key("shodan")
        if shodan_key:
            self._head(f"SHODAN API: {ip}")
            try:
                d = _api_get(f"https://api.shodan.io/shodan/host/{ip}?key={shodan_key}")
                if d and not d.get("error"):
                    for label, val in [
                        ("OS",        d.get("os")),
                        ("Org",       d.get("org")),
                        ("ISP",       d.get("isp")),
                        ("Country",   d.get("country_name")),
                        ("City",      d.get("city")),
                        ("Hostnames", ", ".join(d.get("hostnames", []))),
                        ("Domains",   ", ".join(d.get("domains", []))),
                        ("Last update",d.get("last_update")),
                    ]:
                        if val:
                            self._ok(f"  {label:<12} {val}")
                    ports = [str(s.get("port","")) for s in d.get("data", [])]
                    if ports:
                        self._ok(f"  Open ports   {', '.join(ports)}")
                    for svc in d.get("data", [])[:5]:
                        banner = (svc.get("data","") or "").strip()[:120]
                        if banner:
                            self._info(f"  Port {svc.get('port','?')}/{svc.get('transport','?')} — {banner}")
                elif d and d.get("error"):
                    self._warn(f"Shodan: {d['error']}")
            except Exception as e:
                self._warn(f"Shodan error: {e}")
        else:
            self._info("Shodan API: no key configured")

    # ── WHOIS ─────────────────────────────────────────────────────────────────
    def _whois_lookup(self, target: str):
        self._head(f"WHOIS: {target}")
        self._dbg("ENTER _whois_lookup")
        try:
            import whois as _whois
            w = _whois.whois(target)
            fields = [
                ("Domain",      w.domain_name),
                ("Registrar",   w.registrar),
                ("Created",     w.creation_date),
                ("Expires",     w.expiration_date),
                ("Updated",     w.updated_date),
                ("Status",      w.status),
                ("Name servers",w.name_servers),
                ("Emails",      w.emails),
                ("Org",         w.org),
                ("Country",     w.country),
                ("State",       w.state),
                ("City",        w.city),
                ("Address",     w.address),
                ("DNSSEC",      w.dnssec),
            ]
            for label, val in fields:
                if val:
                    if isinstance(val, list):
                        for v in val:
                            if v:
                                self._ok(f"{label:<14} {v}")
                                if label == "Emails" and v not in self._found_emails:
                                    self._found_emails.append(str(v))
                    else:
                        self._ok(f"{label:<14} {val}")
                        if label == "Emails" and str(val) not in self._found_emails:
                            self._found_emails.append(str(val))
        except Exception as e:
            self._warn(f"WHOIS library error: {e}")
            # Fallback: subprocess whois
            try:
                kw = dict(capture_output=True, text=True, timeout=15,
                          encoding="utf-8", errors="replace")
                if sys.platform == "win32":
                    kw["creationflags"] = subprocess.CREATE_NO_WINDOW
                    # Windows doesn't have whois built in — use nslookup SOA as fallback
                    r = subprocess.run(["nslookup", "-type=SOA", target], **kw)
                else:
                    r = subprocess.run(["whois", target], **kw)
                for line in (r.stdout + r.stderr).splitlines():
                    if line.strip() and not line.startswith("%"):
                        self._info(line.strip())
            except Exception as e2:
                self._err(f"WHOIS fallback error: {e2}")
    # ── Domain→IP ─────────────────────────────────────────────────────────────
    def _domain_to_ip(self, domain: str):
        self._head(f"DOMAIN RESOLUTION: {domain}")
        self._dbg("ENTER _domain_to_ip")
        try:
            ip = socket.gethostbyname(domain)
            self._ok(f"Resolved → {ip}")
            if ip not in self._found_ips:
                self._found_ips.append(ip)
            self._ip_geo(ip)
        except socket.gaierror as e:
            self._err(f"Could not resolve {domain}: {e}")

    # ── Reverse DNS ───────────────────────────────────────────────────────────
    def _reverse_dns(self, ip: str):
        self._head(f"REVERSE DNS: {ip}")
        self._dbg("ENTER _reverse_dns")
        try:
            hostname = socket.gethostbyaddr(ip)
            self._ok(f"Hostname : {hostname[0]}")
            if hostname[1]:
                self._info(f"Aliases  : {', '.join(hostname[1])}")
        except socket.herror:
            self._warn("No reverse DNS record found")
        except Exception as e:
            self._err(f"Reverse DNS error: {e}")

    # ── crt.sh ────────────────────────────────────────────────────────────────
    def _crtsh(self, domain: str):
        self._head(f"CERTIFICATE TRANSPARENCY (crt.sh): {domain}")
        self._dbg("ENTER _crtsh")
        try:
            data = http_get(
                f"https://crt.sh/?q=%.{domain}&output=json",
                timeout=15, json_resp=True
            )
            if not data:
                self._warn("No certificate records found")
                return
            subdomains = set()
            for entry in data:
                for name in entry.get("name_value", "").splitlines():
                    name = name.strip().lstrip("*.")
                    if name.endswith(domain) and name != domain:
                        subdomains.add(name)
            self._ok(f"{len(subdomains)} unique subdomain(s) from cert logs:")
            for sub in sorted(subdomains):
                self._ok(f"  {sub}")
                try:
                    ip = socket.gethostbyname(sub)
                    self._info(f"    → {ip}")
                    if ip not in self._found_ips:
                        self._found_ips.append(ip)
                except Exception:
                    pass
        except Exception as e:
            self._err(f"crt.sh error: {e}")

    # ── Wayback Machine ───────────────────────────────────────────────────────
    def _wayback(self, target: str):
        self._head(f"WAYBACK MACHINE: {target}")
        self._dbg("ENTER _wayback")
        try:
            avail = http_get(
                f"https://archive.org/wayback/available?url={urllib.parse.quote(target)}",
                timeout=10, json_resp=True
            )
            snap = avail.get("archived_snapshots", {}).get("closest", {})
            if not snap.get("available"):
                self._warn("No archived snapshots found")
                return
            self._ok(f"Archived     : YES")
            self._ok(f"Closest snap : {snap.get('timestamp','')[:8]}")
            self._ok(f"URL          : {snap.get('url')}")
            history = http_get(
                f"https://web.archive.org/cdx/search/cdx"
                f"?url={urllib.parse.quote(target)}"
                f"&output=json&limit=10&fl=timestamp,statuscode"
                f"&filter=statuscode:200&collapse=timestamp:8",
                timeout=15, json_resp=True
            )
            if history and len(history) > 1:
                self._info("Snapshot history (up to 10 dates):")
                for row in history[1:]:
                    ts = row[0]
                    date = f"{ts[:4]}-{ts[4:6]}-{ts[6:8]}"
                    self._info(f"  {date}  → https://web.archive.org/web/{ts}/{target}")
        except Exception as e:
            self._err(f"Wayback error: {e}")

    # ── Shodan Public ─────────────────────────────────────────────────────────
    def _shodan(self, target: str):
        self._head(f"SHODAN PUBLIC SEARCH: {target}")
        self._dbg("ENTER _shodan")
        try:
            body = http_get(
                f"https://www.shodan.io/search?query={urllib.parse.quote(target)}",
                timeout=12
            )
            m = re.search(r"([\d,]+)\s+results?\s+found", body, re.IGNORECASE)
            if m:
                self._ok(f"Results found : {m.group(1)}")
            ips_found = list(dict.fromkeys(
                re.findall(r'href="/host/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"', body)
            ))
            if ips_found:
                self._ok(f"Host IPs ({len(ips_found)}):")
                for ip in ips_found[:15]:
                    self._ok(f"  {ip}  → https://www.shodan.io/host/{ip}")
                    if ip not in self._found_ips:
                        self._found_ips.append(ip)
            else:
                self._info("No host IPs parsed (may require login for full results)")
            ports = list(dict.fromkeys(re.findall(r'"port":\s*(\d+)', body)))[:20]
            if ports:
                self._info(f"Ports mentioned: {', '.join(ports)}")
            self._info(f"Full results → https://www.shodan.io/search?query={urllib.parse.quote(target)}")
        except Exception as e:
            self._err(f"Shodan scrape error: {e}")


    # ── SecurityTrails ────────────────────────────────────────────────────────
    def _securitytrails(self, domain: str):
        key = self.config.key("securitytrails")
        self._dbg("ENTER _securitytrails")
        if not key:
            self._info("SecurityTrails: no key configured")
            return
        self._head(f"SECURITYTRAILS: {domain}")
        try:
            d = _api_get(f"https://api.securitytrails.com/v1/domain/{urllib.parse.quote(domain)}",
                         headers={"APIKEY": key})
            if not d:
                self._warn("No response")
                return
            if d.get("message"):
                self._warn(f"SecurityTrails: {d['message']}")
                return
            # Current DNS
            dns_records = d.get("current_dns", {})
            for rtype, rdata in dns_records.items():
                for rec in rdata.get("values", []):
                    val = rec.get("ip") or rec.get("hostname") or rec.get("value","")
                    if val:
                        self._ok(f"  DNS {rtype.upper():<6} {val}")
            # Alexa rank
            alexa = d.get("alexa_rank")
            if alexa:
                self._ok(f"  Alexa rank   : {alexa}")
            # Hostname
            apex = d.get("apex_domain")
            if apex:
                self._info(f"  Apex domain  : {apex}")
            # Subdomains
            sub_d = _api_get(
                f"https://api.securitytrails.com/v1/domain/{urllib.parse.quote(domain)}/subdomains?children_only=false&include_inactive=true",
                headers={"APIKEY": key}
            )
            if sub_d and sub_d.get("subdomains"):
                subs = sub_d["subdomains"][:30]
                self._ok(f"  Subdomains ({sub_d.get('subdomain_count','?')} total, showing {len(subs)}):")
                for s in subs:
                    self._ok(f"    {s}.{domain}")
        except Exception as e:
            self._warn(f"SecurityTrails error: {e}")

    # ── VirusTotal domain ─────────────────────────────────────────────────────
    def _virustotal_domain(self, domain: str):
        key = self.config.key("virustotal")
        self._dbg("ENTER _virustotal_domain")
        if not key:
            self._info("VirusTotal: no key configured")
            return
        self._head(f"VIRUSTOTAL: {domain}")
        try:
            d = _api_get(
                f"https://www.virustotal.com/api/v3/domains/{urllib.parse.quote(domain)}",
                headers={"x-apikey": key}
            )
            if not d or d.get("error"):
                self._warn(f"VirusTotal: {d.get('error',{}).get('message','error') if d else 'no response'}")
                return
            attrs = d.get("data", {}).get("attributes", {})
            # Reputation
            rep = attrs.get("reputation", 0)
            rep_col = COL_ERR if rep < -10 else COL_WARN if rep < 0 else COL_OK
            self.log_signal.emit(
                f"[{datetime.now().strftime('%H:%M:%S')}]    Reputation     : {rep}", rep_col
            )
            # Last analysis stats
            stats = attrs.get("last_analysis_stats", {})
            if stats:
                self._ok(f"  Malicious    : {stats.get('malicious',0)}")
                self._ok(f"  Suspicious   : {stats.get('suspicious',0)}")
                self._info(f"  Harmless     : {stats.get('harmless',0)}")
                self._info(f"  Undetected   : {stats.get('undetected',0)}")
            # Categories
            cats = attrs.get("categories", {})
            if cats:
                unique_cats = list(set(cats.values()))[:5]
                self._info(f"  Categories   : {', '.join(unique_cats)}")
            # WHOIS
            whois_date = attrs.get("whois_date")
            if whois_date:
                self._info(f"  WHOIS date   : {datetime.utcfromtimestamp(whois_date).strftime('%Y-%m-%d')}")
            # Registrar
            registrar = attrs.get("registrar")
            if registrar:
                self._info(f"  Registrar    : {registrar}")
            # DNS records from VT
            for rtype in ["A", "MX", "NS"]:
                records = attrs.get(f"last_dns_records", [])
                typed = [r.get("value","") for r in records if r.get("type","") == rtype]
                if typed:
                    self._ok(f"  {rtype:<6}        : {', '.join(typed[:5])}")
        except Exception as e:
            self._warn(f"VirusTotal error: {e}")

    # ── Paste Site Search ─────────────────────────────────────────────────────
    def _paste_search(self, query: str):
        self._head(f"PASTE SITE SEARCH: {query}")
        self._dbg("ENTER _paste_search")
        q = urllib.parse.quote_plus(f'"{query}"')
        paste_dorks = [
            ("Pastebin",    f"https://www.google.com/search?q={q}+site:pastebin.com"),
            ("Ghostbin",    f"https://www.google.com/search?q={q}+site:ghostbin.com"),
            ("Rentry",      f"https://www.google.com/search?q={q}+site:rentry.co"),
            ("Hastebin",    f"https://www.google.com/search?q={q}+site:hastebin.com"),
            ("GitHub Gist", f"https://www.google.com/search?q={q}+site:gist.github.com"),
            ("Slexy",       f"https://www.google.com/search?q={q}+site:slexy.org"),
            ("Paste.ee",    f"https://www.google.com/search?q={q}+site:paste.ee"),
        ]
        # GitHub code search API requires authentication — use search link instead
        gh_search = f"https://github.com/search?q={urllib.parse.quote_plus(query)}&type=code"
        self._info(f"GitHub code search (requires login): {gh_search}")

        self._info("Opening paste dork searches in browser...")
        for label, url in paste_dorks:
            if not self._running:
                break
            self._info(f"  {label}: {url}")



# ─────────────────────────────────────────────────────────────────────────────
# Claude AI Summary
# ─────────────────────────────────────────────────────────────────────────────
def build_findings_digest(log_text: str, query: str, input_type: str,
                           deep_findings: dict = None) -> dict:
    """Extract structured findings from the plain-text log."""
    emails   = extract_emails(log_text)
    ips      = extract_ips(log_text)
    profiles = re.findall(r"✓.*?(https?://\S+)", log_text)
    breaches = re.findall(r"·\s+([^(]+)\(([^)]+)\)\s+—\s+(.+)", log_text)
    domains  = re.findall(r"(?:Domain\s+:\s+|Resolved →\s+)([\w\.-]+)", log_text)
    phone_lines = [l.strip() for l in log_text.splitlines()
                   if any(k in l for k in ["Valid","Carrier","Region","E.164","Line type"])]
    d = {
        "query":       query,
        "input_type":  input_type,
        "emails":      list(set(emails))[:20],
        "ips":         list(set(ips))[:20],
        "profiles":    list(set(profiles))[:30],
        "breaches":    [{"name":b[0].strip(),"date":b[1],"data":b[2].strip()} for b in breaches[:10]],
        "domains":     list(set(domains))[:10],
        "phone_data":  phone_lines[:10],
    }
    if deep_findings:
        d.update({
            "education":       deep_findings.get("education", [])[:10],
            "employers":       deep_findings.get("employers", [])[:10],
            "patents":         deep_findings.get("patents", [])[:10],
            "court_cases":     deep_findings.get("court_cases", [])[:10],
            "sec_roles":       deep_findings.get("sec_roles", [])[:10],
            "fec_donations":   deep_findings.get("fec_donations", [])[:10],
            "publications":    deep_findings.get("publications", [])[:10],
            "code_contributions": deep_findings.get("code_contributions", [])[:10],
        })
    return d


def run_claude_summary(log_text: str, query: str, input_type: str,
                       api_key: str, model: str,
                       deep_findings: dict = None) -> tuple[bool, str]:
    """Call Claude API and return (ok, text)."""
    digest = build_findings_digest(log_text, query, input_type, deep_findings)

    system_prompt = (
        "You are an expert OSINT analyst. You will receive structured findings from an "
        "automated OSINT scan and produce a full intelligence report. "
        "Be thorough, analytical, and highlight risks, patterns, and actionable insights. "
        "Format the report with clear sections. Do not invent information not present in the data."
    )

    user_prompt = f"""OSINT SCAN FINDINGS

Target: {query}
Input type: {input_type}

Structured findings:
{json.dumps(digest, indent=2)}

Please produce a full intelligence report covering:
1. Executive Summary
2. Identity Analysis (what can be inferred about the target)
3. Digital Footprint (platforms, profiles, online presence)
4. Email Intelligence (validity, breaches, risk)
5. Infrastructure (IPs, domains, hosting)
6. Phone Intelligence (if applicable)
7. Risk Assessment (threat level, exposure, privacy risks)
8. Recommended Next Steps (further investigation vectors)
9. Notable Gaps (what was not found / inconclusive)
"""

    try:
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps({
                "model":      model,
                "max_tokens": 2048,
                "system":     system_prompt,
                "messages":   [{"role": "user", "content": user_prompt}]
            }).encode(),
            headers={
                "x-api-key":         api_key,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json",
            }
        )
        req.get_method = lambda: "POST"
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode())
            text = "".join(
                block.get("text","")
                for block in data.get("content",[])
                if block.get("type") == "text"
            )
            return True, text
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        return False, f"HTTP {e.code}: {body[:200]}"
    except Exception as e:
        return False, str(e)



# ─────────────────────────────────────────────────────────────────────────────
# Deep Search Worker
# ─────────────────────────────────────────────────────────────────────────────
def _name_split(name: str) -> tuple[str, str, str]:
    """Split name into (first, middle, last).
    Middle is empty string if not provided.
    Returns (first, middle, last).
    """
    parts = name.strip().split()
    if len(parts) == 1:
        return parts[0], "", parts[0]
    if len(parts) == 2:
        return parts[0], "", parts[1]
    # 3+ parts: first = parts[0], last = parts[-1], middle = everything between
    return parts[0], " ".join(parts[1:-1]), parts[-1]


# ─────────────────────────────────────────────────────────────────────────────
# OSINT Thread
# ─────────────────────────────────────────────────────────────────────────────
class OSINTThread(QThread):
    log_signal  = pyqtSignal(str, str)
    done_signal = pyqtSignal()

    def __init__(self, query, input_type, extended, config=None):
        super().__init__()
        self._query      = query
        self._input_type = input_type
        self._extended   = extended
        self._config     = config
        self._worker     = None

    def _dbg(self, msg: str):
        try:
            dbg_path = APP_DATA_DIR / "osint_crash_debug.txt"
            with open(dbg_path, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().strftime('%H:%M:%S.%f')} [{self._input_type}] {msg}\n")
                f.flush()
                import os; os.fsync(f.fileno())
        except Exception:
            pass

    def run(self):
        self._dbg(f"run() START query={self._query!r}")
        self._worker = OSINTWorker(
            self._query, self._input_type, self._extended, config=self._config
        )
        self._worker.log_signal.connect(
            self.log_signal, Qt.ConnectionType.QueuedConnection
        )
        self._worker.done_signal.connect(
            self.done_signal, Qt.ConnectionType.QueuedConnection
        )
        self._worker.run()

    def stop(self):
        if self._worker:
            self._worker.stop()

    def pending_urls(self) -> list:
        return self._worker._pending_urls if self._worker else []


class DeepSearchWorker:
    """Pure Python worker — no QObject, no signals. Thread-safe."""

    def __init__(self, name: str, config, emit_fn, dbg_fn):
        self.name     = name.strip()
        self.config   = config
        self._emit    = emit_fn   # callable(msg, colour)
        self._dbg     = dbg_fn    # callable(msg)
        self._running = True
        self._findings: dict = {
            "education":        [],
            "employers":        [],
            "patents":          [],
            "court_cases":      [],
            "sec_roles":        [],
            "fec_donations":    [],
            "publications":     [],
            "code_contributions":[],
        }

    def stop(self):
        self._running = False

    def _log(self, msg: str, col: str = COL_INFO):
        ts = datetime.now().strftime("%H:%M:%S")
        self._emit(f"[{ts}]  {msg}", col)

    def _head(self, t: str):
        self._emit("", COL_INFO)
        self._emit(f"[{datetime.now().strftime('%H:%M:%S')}]  ══  {t}  " + "═"*max(0,50-len(t)), COL_HEAD)

    def _ok(self,   m: str): self._log(f"  ✓  {m}", COL_OK)
    def _warn(self, m: str): self._log(f"  ⚠  {m}", COL_WARN)
    def _err(self,  m: str): self._log(f"  ✗  {m}", COL_ERR)
    def _info(self, m: str): self._log(f"  ·  {m}", COL_INFO)

    def run(self):
        self._dbg("DeepSearchWorker.run() START")
        first, middle, last = _name_split(self.name)
        self._dbg(f"name: {first} / {middle or '—'} / {last}")
        q_full = urllib.parse.quote_plus(f'"{self.name}"')
        self._dbg("entering tasks")
        self._dbg("about to call _emit directly")
        try:
            self._emit("[TEST] deep search emit test", COL_INFO)
            self._dbg("_emit direct call OK")
        except Exception as e:
            self._dbg(f"_emit direct FAILED: {e}")
        self._dbg("calling _head")
        self._head(f"DEEP SEARCH: {self.name}")
        self._dbg("_head done")
        self._info(f"First: {first}  Last: {last}")
        self._dbg("_info done, building task list")

        tasks = [
            ("Education",            lambda: self._education(first, middle, last)),
            ("Employers/Companies",  lambda: self._companies(first, middle, last)),
            ("Professional Licenses",lambda: self._licenses(q_full)),
            ("Publications",         lambda: self._publications(first, middle, last)),
            ("Patents",              lambda: self._patents(first, middle, last)),
            ("Court Records",        lambda: self._courts(first, middle, last)),
            ("SEC Filings",          lambda: self._sec(first, middle, last)),
            ("Campaign Finance",     lambda: self._fec(first, middle, last)),
            ("Property Records",     lambda: self._property(q_full)),
            ("Voter Registration",   lambda: self._voter(q_full)),
            ("Obituaries/Genealogy", lambda: self._genealogy(q_full)),
            ("News Archives",        lambda: self._news(q_full)),
            ("Arrest Records",       lambda: self._arrests(q_full)),
            ("Code Contributions",   lambda: self._code(first, last)),
            ("Domain Registrations", lambda: self._domains(q_full)),
        ]

        for name, fn in tasks:
            if not self._running:
                break
            self._dbg(f"deep task START: {name}")
            try:
                fn()
            except Exception as e:
                self._err(f"{name} error: {e}")
            self._dbg(f"deep task DONE: {name}")

        self._head("DEEP SEARCH COMPLETE")

    def _education(self, first, middle, last):
        self._head("EDUCATION")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        if middle: self._info(f"Searching with middle name: {full_name}")
        q = urllib.parse.quote_plus(full_name)
        try:
            key = self.config.key("data_gov") or "DEMO_KEY"
            url = f"https://api.data.gov/ed/collegescorecard/v1/schools?school.name={urllib.parse.quote_plus(last)}&fields=school.name,school.city,school.state&per_page=5&api_key={key}"
            d = _api_get(url, timeout=10)
            if d and d.get("results"):
                self._ok(f"College Scorecard: {len(d['results'])} institution(s) matching '{last}'")
                for r in d["results"][:5]:
                    self._ok(f"  {r.get('school.name','?')} — {r.get('school.city','')}, {r.get('school.state','')}")
                    self._findings["education"].append(r.get("school.name","?"))
        except Exception as e:
            self._warn(f"College Scorecard: {e}")
        links = [
            ("Alumni/graduation dork", f"https://www.google.com/search?q=%22{q}%22+%22alumni%22+OR+%22graduated%22"),
            ("site:edu",               f"https://www.google.com/search?q=%22{q}%22+site:edu"),
            ("Academia.edu",           f"https://www.google.com/search?q=%22{q}%22+site:academia.edu"),
            ("LinkedIn education",     f"https://www.google.com/search?q=%22{q}%22+site:linkedin.com+%22university%22+OR+%22college%22"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _companies(self, first, middle, last):
        self._head("EMPLOYERS / COMPANIES")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        if middle: self._info(f"Searching with middle name: {full_name}")
        q = urllib.parse.quote_plus(full_name)
        try:
            d = _api_get(f"https://api.opencorporates.com/v0.4/officers/search?q={urllib.parse.quote_plus(full_name)}&per_page=10", timeout=12)
            if d and d.get("results",{}).get("officers"):
                officers = d["results"]["officers"]
                self._ok(f"OpenCorporates: {len(officers)} officer record(s)")
                for o in officers[:10]:
                    off  = o.get("officer",{})
                    role = off.get("position","?")
                    comp = off.get("company",{}).get("name","?")
                    jur  = off.get("company",{}).get("jurisdiction_code","?")
                    self._ok(f"  {role} at {comp} ({jur.upper()})")
                    self._findings["employers"].append(f"{role} at {comp}")
                self._info("  · Data provided by OpenCorporates (opencorporates.com)")
            else:
                self._info("OpenCorporates: no officer records found")
        except Exception as e:
            self._warn(f"OpenCorporates: {e}")
        links = [
            ("LinkedIn",        f"https://www.google.com/search?q=%22{q}%22+site:linkedin.com"),
            ("Crunchbase",      f"https://www.google.com/search?q=%22{q}%22+site:crunchbase.com"),
            ("Companies House", f"https://find-and-update.company-information.service.gov.uk/search?q={urllib.parse.quote_plus(name)}"),
            ("Bloomberg",       f"https://www.google.com/search?q=%22{q}%22+site:bloomberg.com/profile"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _licenses(self, q_full):
        self._head("PROFESSIONAL LICENSES")
        links = [
            ("NPPES Medical",   f"https://npiregistry.cms.hhs.gov/search?searchType=ind&name={q_full}"),
            ("FINRA BrokerCheck",f"https://brokercheck.finra.org/search/genericsearch/grid?query={q_full}"),
            ("License dork",    f"https://www.google.com/search?q={q_full}+%22license%22+OR+%22certified%22"),
            ("State bar dork",  f"https://www.google.com/search?q={q_full}+site:calbar.ca.gov+OR+site:nysba.org"),
            ("Real estate",     f"https://www.google.com/search?q={q_full}+%22real+estate+license%22"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _publications(self, first, middle, last):
        self._head("PUBLICATIONS / RESEARCH")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        if middle: self._info(f"Searching with middle name: {full_name}")
        q = urllib.parse.quote_plus(full_name)
        try:
            d = _api_get(
                f"https://pub.orcid.org/v3.0/search?q=family-name:{urllib.parse.quote_plus(last)}+AND+given-names:{urllib.parse.quote_plus(first)}&rows=5",
                headers={"Accept": "application/json"}, timeout=10)
            if d and d.get("result"):
                self._ok(f"ORCID: {d.get('num-found',0)} profile(s)")
                for r in d["result"][:5]:
                    oid = r.get("orcid-identifier",{}).get("path","")
                    if oid:
                        self._ok(f"  https://orcid.org/{oid}")
                        self._findings["publications"].append(f"ORCID:{oid}")
        except Exception as e:
            self._warn(f"ORCID: {e}")
        try:
            d = _api_get(
                f"https://api.crossref.org/works?query.author={urllib.parse.quote_plus(full_name)}&rows=5&select=title,DOI,published",
                headers={"User-Agent":"OSINTofDeath/5.0"}, timeout=10)
            if d and d.get("message",{}).get("items"):
                items = d["message"]["items"]
                total = d["message"].get("total-results",0)
                self._ok(f"CrossRef: {total} publication(s), showing {len(items)}")
                for item in items[:10]:
                    title = (item.get("title") or ["?"])[0]
                    doi   = item.get("DOI","")
                    yr    = (item.get("published",{}).get("date-parts") or [[""]])[0][0]
                    self._ok(f"  [{yr}] {title}")
                    if doi: self._info(f"       https://doi.org/{doi}")
                    self._findings["publications"].append(title)
        except Exception as e:
            self._warn(f"CrossRef: {e}")
        links = [
            ("Google Scholar", f"https://scholar.google.com/scholar?q={q}"),
            ("PubMed",         f"https://pubmed.ncbi.nlm.nih.gov/?term={q}"),
            ("arXiv",          f"https://arxiv.org/search/?searchtype=author&query={q}"),
            ("ResearchGate",   f"https://www.google.com/search?q=%22{q}%22+site:researchgate.net"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _patents(self, first, middle, last):
        self._head("PATENTS")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        q = urllib.parse.quote_plus(name)
        if middle:
            self._info(f"Searching: {full_name}")

        # PatentsView new API (post March 2026 migration to USPTO ODP)
        # Uses GET with q parameter and X-Api-Key header (key optional for basic queries)
        try:
            query = json.dumps({"_and": [
                {"inventors_at_grant.name_last":  last},
                {"inventors_at_grant.name_first": first},
            ]})
            fields = json.dumps([
                "patent_id", "patent_title", "patent_date",
                "assignees_at_grant.assignee_organization"
            ])
            pv_key = self.config.key("patentsview")
            headers = {"User-Agent": "OSINTofDeath/5.0"}
            if pv_key:
                headers["X-Api-Key"] = pv_key
            else:
                self._info("PatentsView: no API key — results may be limited (Settings → API Keys)")
            url = (f"https://search.patentsview.org/api/v1/patent/"
                   f"?q={urllib.parse.quote(query)}"
                   f"&f={urllib.parse.quote(fields)}"
                   f"&o={urllib.parse.quote(json.dumps({'size': 10}))}")
            d = _api_get(url, headers=headers, timeout=12)
            if d and not d.get("error"):
                patents = d.get("patents", [])
                total   = d.get("total_hits", len(patents))
                if total:
                    self._ok(f"PatentsView: {total} patent(s), showing {min(len(patents),10)}")
                    for p in patents[:10]:
                        pid   = p.get("patent_id","?")
                        title = p.get("patent_title","?")
                        date  = p.get("patent_date","?")
                        assignees = p.get("assignees_at_grant") or []
                        org = assignees[0].get("assignee_organization","—") if assignees else "—"
                        self._ok(f"  US{pid} [{date}] {title}")
                        self._info(f"    Assignee: {org}")
                        self._info(f"    https://patents.google.com/patent/US{pid}")
                        self._findings["patents"].append(f"US{pid}: {title}")
                    if total > 10:
                        self._info(f"  More: https://search.patentsview.org/api/v1/patent/?q={urllib.parse.quote(query)}")
                else:
                    self._info("PatentsView: no patents found")
            elif d and d.get("error"):
                self._warn(f"PatentsView: {d['error']}")
            else:
                self._warn("PatentsView: no response")
        except Exception as e:
            self._warn(f"PatentsView: {e}")

        self._info(f"  Google Patents: https://patents.google.com/?inventor={q}")
        self._info(f"  USPTO search:   https://ppubs.uspto.gov/pubwebapp/")

    def _courts(self, first, middle, last):
        self._head("COURT RECORDS")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        if middle: self._info(f"Searching with middle name: {full_name}")
        q = urllib.parse.quote_plus(full_name)
        cl_key = self.config.key("courtlistener")
        if cl_key:
            try:
                d = _api_get(f"https://www.courtlistener.com/api/rest/v4/dockets/?q={urllib.parse.quote_plus(full_name)}&order_by=score+desc&page_size=10", headers={"Authorization":f"Token {cl_key}"})
                if d and d.get("results"):
                    self._ok(f"CourtListener: {d.get('count',0)} case(s)")
                    for case in d["results"][:10]:
                        self._ok(f"  {case.get('case_name','?')} — {case.get('court','?')} [{case.get('date_filed','?')}]")
                        self._findings["court_cases"].append(case.get("case_name","?"))
                else:
                    self._info("CourtListener: no cases found")
            except Exception as e:
                self._warn(f"CourtListener: {e}")
        else:
            self._info("CourtListener: no key configured (Settings → API Keys)")
        links = [
            ("CourtListener",  f"https://www.courtlistener.com/?q={q}"),
            ("Justia",         f"https://www.google.com/search?q=%22{q}%22+site:law.justia.com"),
            ("Court dork",     f"https://www.google.com/search?q=%22{q}%22+%22plaintiff%22+OR+%22defendant%22"),
            ("Unicourt",       f"https://unicourt.com/search#q={q}"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _sec(self, first, middle, last):
        self._head("SEC FILINGS / EDGAR")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        if middle: self._info(f"Searching with middle name: {full_name}")
        q = urllib.parse.quote_plus(full_name)
        try:
            d = _api_get(f"https://efts.sec.gov/LATEST/search-index?q=%22{urllib.parse.quote_plus(full_name)}%22&forms=DEF+14A,10-K,4,3,5&hits.hits._source=file_date,entity_name,form_type", headers={"User-Agent":"OSINTofDeath research@example.com"}, timeout=12)
            if d and d.get("hits",{}).get("hits"):
                hits = d["hits"]["hits"]
                total = d["hits"].get("total",{}).get("value",0)
                self._ok(f"EDGAR: {total} filing(s), showing {min(len(hits),10)}")
                for h in hits[:10]:
                    src = h.get("_source",{})
                    self._ok(f"  {src.get('form_type','?')} — {src.get('entity_name','?')} [{src.get('file_date','?')}]")
                    self._findings["sec_roles"].append(f"{src.get('form_type')} at {src.get('entity_name')}")
            else:
                self._info("EDGAR: no filings found")
        except Exception as e:
            self._warn(f"EDGAR: {e}")
        self._info(f"  EDGAR: https://efts.sec.gov/LATEST/search-index?q=%22{q}%22")

    def _fec(self, first, middle, last):
        self._head("CAMPAIGN FINANCE (FEC)")
        name = f"{first} {last}"
        full_name = f"{first} {middle} {last}" if middle else name
        if middle: self._info(f"Searching with middle name: {full_name}")
        q = urllib.parse.quote_plus(full_name)
        try:
            key = self.config.key("fec") or "DEMO_KEY"
            d = _api_get(f"https://api.open.fec.gov/v1/schedules/schedule_a/?contributor_name={urllib.parse.quote_plus(full_name)}&per_page=10&api_key={key}&sort=-contribution_receipt_date", timeout=12)
            if d and d.get("results"):
                total = d.get("pagination",{}).get("count",0)
                self._ok(f"FEC: {total} donation(s)")
                for don in d["results"][:10]:
                    amt   = don.get("contribution_receipt_amount","?")
                    recip = don.get("committee",{}).get("name","?")
                    date  = don.get("contribution_receipt_date","?")
                    self._ok(f"  ${amt} → {recip} [{date}]")
                    self._findings["fec_donations"].append(f"${amt} to {recip}")
            else:
                self._info("FEC: no donation records found")
        except Exception as e:
            self._warn(f"FEC: {e}")
        self._info(f"  FEC: https://www.fec.gov/data/receipts/individual-contributions/?contributor_name={q}")

    def _property(self, q_full):
        self._head("PROPERTY RECORDS")
        links = [
            ("Zillow dork",     f"https://www.google.com/search?q={q_full}+site:zillow.com"),
            ("County assessor", f"https://www.google.com/search?q={q_full}+%22property+owner%22+OR+%22assessor%22"),
            ("Realtor.com",     f"https://www.google.com/search?q={q_full}+site:realtor.com"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _voter(self, q_full):
        self._head("VOTER REGISTRATION")
        self._info("Note: availability varies by state")
        links = [
            ("VoterRecords.com", f"https://voterrecords.com/voters/{q_full}"),
            ("Voter dork",       f"https://www.google.com/search?q={q_full}+%22voter+registration%22"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _genealogy(self, q_full):
        self._head("OBITUARIES / GENEALOGY")
        links = [
            ("Find-a-Grave",  f"https://www.findagrave.com/memorial/search?q={q_full}"),
            ("Ancestry dork", f"https://www.google.com/search?q={q_full}+site:ancestry.com"),
            ("Legacy.com",    f"https://www.legacy.com/search/?q={q_full}"),
            ("Obit dork",     f"https://www.google.com/search?q={q_full}+%22obituary%22"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _news(self, q_full):
        self._head("NEWS ARCHIVES")
        q_raw = urllib.parse.unquote_plus(q_full).strip('"')
        try:
            d = _api_get(f"https://chroniclingamerica.loc.gov/search/pages/results/?andtext={urllib.parse.quote_plus(q_raw)}&format=json&rows=5", timeout=10)
            if d and d.get("items"):
                self._ok(f"Chronicling America: {d.get('totalItems',0)} historic mention(s)")
                for item in d["items"][:5]:
                    self._ok(f"  [{item.get('date','?')}] {item.get('title','?')}")
        except Exception as e:
            self._warn(f"Chronicling America: {e}")
        links = [
            ("Google News",  f"https://news.google.com/search?q={q_full}"),
            ("AP News",      f"https://apnews.com/search?q={q_full}"),
            ("NYT dork",     f"https://www.google.com/search?q={q_full}+site:nytimes.com"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _arrests(self, q_full):
        self._head("ARREST / PUBLIC RECORDS")
        links = [
            ("Arrests.org dork",   f"https://www.google.com/search?q={q_full}+site:arrests.org"),
            ("Mugshots dork",      f"https://www.google.com/search?q={q_full}+site:mugshots.com"),
            ("Arrest dork",        f"https://www.google.com/search?q={q_full}+%22arrested%22+OR+%22charged%22+OR+%22indicted%22"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _code(self, first, last):
        self._head("CODE CONTRIBUTIONS")
        name = f"{first} {last}"
        q = urllib.parse.quote_plus(name)
        try:
            d = _api_get(f"https://registry.npmjs.org/-/v1/search?text=author:{urllib.parse.quote_plus(last.lower())}&size=5", timeout=8)
            if d and d.get("objects"):
                self._ok(f"npm: {d.get('total',0)} package(s)")
                for obj in d["objects"][:10]:
                    pkg = obj.get("package",{})
                    self._ok(f"  {pkg.get('name','?')} — {pkg.get('description','')[:60]}")
                    self._findings["code_contributions"].append(pkg.get("name","?"))
        except Exception as e:
            self._warn(f"npm: {e}")
        links = [
            ("GitHub",     f"https://github.com/search?q={q}&type=users"),
            ("PyPI",       f"https://pypi.org/search/?q={q}"),
            ("GitLab",     f"https://gitlab.com/search?search={q}&scope=users"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")

    def _domains(self, q_full):
        self._head("DOMAIN REGISTRATIONS")
        q_raw = urllib.parse.unquote_plus(q_full).strip('"')
        q = urllib.parse.quote_plus(q_raw)
        links = [
            ("ViewDNS reverse WHOIS", f"https://viewdns.info/reversewhois/?q={q}"),
            ("DomainBigData",         f"https://domainbigdata.com/name/{q}"),
            ("WHOIS dork",            f"https://www.google.com/search?q=%22{urllib.parse.quote_plus(q_raw)}%22+%22registrant%22+OR+%22whois%22"),
        ]
        for label, link in links:
            self._info(f"  {label}: {link}")


class DeepSearchThread(QThread):
    log_signal  = pyqtSignal(str, str)
    done_signal = pyqtSignal()

    def __init__(self, name: str, config):
        super().__init__()
        self._name    = name
        self._config  = config
        self._worker  = None
        self._queue   = _pyqueue.Queue()  # plain Python queue — thread-safe, no Qt

    def run(self):
        # Drain queue and emit signals — this runs on the QThread
        def _emit(msg: str, col: str):
            self._queue.put((msg, col))

        def _dbg(msg: str):
            try:
                dbg_path = APP_DATA_DIR / "osint_crash_debug.txt"
                with open(dbg_path, "a", encoding="utf-8") as f:
                    f.write(f"{datetime.now().strftime('%H:%M:%S.%f')} [DEEP] {msg}\n")
                    f.flush()
                    import os; os.fsync(f.fileno())
            except Exception:
                pass

        _dbg("DeepSearchThread.run() start")
        _dbg("creating worker")
        self._worker = DeepSearchWorker(self._name, self._config, _emit, _dbg)
        _dbg("worker created, calling run()")
        self._worker.run()
        _dbg("worker.run() complete")

        # Drain any remaining queue items
        while not self._queue.empty():
            try:
                msg, col = self._queue.get_nowait()
                self.log_signal.emit(msg, col)
            except Exception:
                break

        self.done_signal.emit()

    def _flush_queue(self):
        """Called periodically by timer to forward log messages to UI."""
        try:
            while not self._queue.empty():
                msg, col = self._queue.get_nowait()
                self.log_signal.emit(msg, col)
        except Exception:
            pass

    def stop(self):
        if self._worker:
            self._worker.stop()

    def findings(self) -> dict:
        return self._worker._findings if self._worker else {}

class HistoryDialog(QDialog):
    def __init__(self, history: HistoryManager, parent=None):
        super().__init__(parent)
        self.history     = history
        self.rerun_entry = None
        self.setWindowTitle("Search History — OSINT of Death")
        self.setMinimumSize(1000, 620)
        self.setStyleSheet(DLGSTYLE)
        lay = QHBoxLayout(self)
        spl = QSplitter(Qt.Orientation.Horizontal)
        self.list_w = QListWidget()
        for e in history.entries:
            ts   = e.get("timestamp", "")[:19]
            item = QListWidgetItem(f"[{ts}]  {e.get('type','')}: {e.get('query','')}")
            item.setData(Qt.ItemDataRole.UserRole, e)
            self.list_w.addItem(item)
        self.list_w.currentItemChanged.connect(
            lambda cur, _: self.log_v.setPlainText(
                cur.data(Qt.ItemDataRole.UserRole).get("log","") if cur else ""
            )
        )
        right     = QWidget()
        right_lay = QVBoxLayout(right)
        self.log_v = QTextEdit()
        self.log_v.setReadOnly(True)
        self.log_v.setFont(QFont("Courier", 10))
        btn_row = QHBoxLayout()
        for label, slot in [("▶  Re-run", self._rerun),
                             ("✗  Delete", self._delete),
                             ("🗑  Clear All", self._clear_all)]:
            btn = QPushButton(label); btn.clicked.connect(slot); btn_row.addWidget(btn)
        right_lay.addWidget(self.log_v)
        right_lay.addLayout(btn_row)
        spl.addWidget(self.list_w); spl.addWidget(right); spl.setSizes([320, 680])
        lay.addWidget(spl)

    def _rerun(self):
        row = self.list_w.currentRow()
        if row >= 0:
            self.rerun_entry = self.list_w.item(row).data(Qt.ItemDataRole.UserRole)
            self.accept()

    def _delete(self):
        row = self.list_w.currentRow()
        if row >= 0:
            self.list_w.takeItem(row)
            if row < len(self.history.entries):
                self.history.entries.pop(row); self.history.save()

    def _clear_all(self):
        self.list_w.clear(); self.history.entries = []; self.history.save()


# ─────────────────────────────────────────────────────────────────────────────
# Splash
# ─────────────────────────────────────────────────────────────────────────────
def create_splash():
    try:
        splash_path = Path(__file__).parent / "splash.png"
        pixmap = QPixmap(str(splash_path)) if splash_path.exists() else QPixmap(800, 600)
        if pixmap.isNull():
            pixmap = QPixmap(800, 600)
        pixmap.fill(QColor(10, 10, 10)) if not splash_path.exists() else None
        if pixmap.width() != 800 or pixmap.height() != 600:
            pixmap = pixmap.scaled(800, 600,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation)
        painter = QPainter(pixmap)
        white   = QColor(255, 255, 255)
        painter.setPen(white)
        painter.setFont(QFont("Courier", 36, QFont.Weight.Bold))
        tr = pixmap.rect(); tr.setTop(30); tr.setBottom(100)
        painter.drawText(tr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
        painter.setFont(QFont("Courier", 13, QFont.Weight.Bold))
        fr = pixmap.rect(); fr.setTop(pixmap.height() - 60); fr.setBottom(pixmap.height() - 20)
        painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e); return None


# ─────────────────────────────────────────────────────────────────────────────
# Main Window
# ─────────────────────────────────────────────────────────────────────────────
MAINSTYLE = f"""
    QMainWindow, QWidget {{ background-color:{C_BG}; color:{C_GREEN}; font-family:Courier; }}
    QLineEdit  {{ background:{C_PANEL}; color:{C_GREEN}; border:1px solid {C_BORDER}; padding:6px; font-family:Courier; font-size:13px; }}
    QLineEdit:focus {{ border:1px solid {C_GREEN2}; }}
    QComboBox  {{ background:{C_PANEL}; color:{C_GREEN}; border:1px solid {C_BORDER}; padding:5px; font-family:Courier; font-size:12px; }}
    QComboBox QAbstractItemView {{ background:{C_PANEL}; color:{C_GREEN}; selection-background-color:{C_DARK}; }}
    QTextEdit  {{ background:{C_PANEL}; color:{C_GREEN}; border:1px solid {C_BORDER}; font-family:Courier; font-size:11px; }}
    QPushButton {{ background:{C_DARK}; color:{C_GREEN}; border:1px solid {C_GREEN2}; padding:7px 14px; font-family:Courier; font-size:12px; font-weight:bold; }}
    QPushButton:hover {{ background:#005500; border:1px solid {C_GREEN}; }}
    QPushButton:disabled {{ background:#111; color:#333; border:1px solid #222; }}
    QCheckBox {{ color:{C_GREEN2}; font-family:Courier; font-size:12px; }}
    QCheckBox::indicator {{ width:14px; height:14px; border:1px solid {C_GREEN2}; background:{C_PANEL}; }}
    QCheckBox::indicator:checked {{ background:{C_GREEN2}; }}
    QScrollBar:vertical {{ background:{C_PANEL}; width:10px; }}
    QScrollBar::handle:vertical {{ background:{C_DARK}; min-height:20px; }}
    QScrollBar:horizontal {{ background:{C_PANEL}; height:10px; }}
    QScrollBar::handle:horizontal {{ background:{C_DARK}; }}
"""

class OSINTMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.history      = HistoryManager()
        self.config       = ConfigManager()
        self.thread       = None
        self.deep_thread  = None
        self._last_log    = ""
        self.setWindowTitle(f"{APP_NAME} v{VERSION} — {ORG_NAME}")
        self.setMinimumSize(1024, 768)
        # Prefer .ico for better Windows taskbar/menu quality
        ico_path = Path(__file__).parent / "osint_of_death.ico"
        png_path = Path(__file__).parent / "splash.png"
        if ico_path.exists():
            self.setWindowIcon(QIcon(str(ico_path)))
        elif png_path.exists():
            self.setWindowIcon(QIcon(str(png_path)))
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
            except Exception:
                pass
        self._build_ui()
        self.setStyleSheet(MAINSTYLE)
        self._restore_geometry()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        title = QLabel(f"☠   {APP_NAME}   ☠")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("Courier", 20, QFont.Weight.Bold))
        title.setStyleSheet(f"color:{C_GREEN}; padding:4px;")
        root.addWidget(title)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color:{C_BORDER};"); root.addWidget(sep)

        sr = QHBoxLayout()
        self.type_combo = QComboBox()
        self.type_combo.addItems(INPUT_TYPES)
        self.type_combo.setFixedWidth(145)
        self.type_combo.setToolTip("Input type — auto-detected or override")

        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Enter name, email, phone, username, IP, or domain...")
        self.search_bar.returnPressed.connect(self._start_search)
        self.search_bar.textChanged.connect(self._auto_detect)

        self.ext_cb = QCheckBox("Deep Search")
        self.ext_cb.setToolTip("Run deep search modules after standard scan (patents, court records, SEC, education, etc.)")

        self.search_btn = QPushButton("⚡  SEARCH")
        self.search_btn.setFixedWidth(130)
        self.search_btn.clicked.connect(self._start_search)

        self.stop_btn = QPushButton("■  STOP")
        self.stop_btn.setFixedWidth(100)
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._stop_search)

        for w in [self.type_combo, self.search_bar, self.ext_cb,
                  self.search_btn, self.stop_btn]:
            sr.addWidget(w)
        root.addLayout(sr)

        self.log_view = QTextBrowser()
        self.log_view.setFont(QFont("Courier", 11))
        self.log_view.setLineWrapMode(QTextBrowser.LineWrapMode.NoWrap)
        self.log_view.setOpenLinks(True)
        self.log_view.setOpenExternalLinks(True)
        root.addWidget(self.log_view, stretch=1)

        br = QHBoxLayout()
        self.status_lbl = QLabel("Ready.")
        self.status_lbl.setStyleSheet(f"color:{C_GREEN2}; font-family:Courier; font-size:11px;")
        br.addWidget(self.status_lbl, stretch=1)

        self.summarize_btn = QPushButton("🤖  Summarize")
        self.summarize_btn.setToolTip("Generate Claude AI intelligence report from current log")
        self.summarize_btn.clicked.connect(self._run_summary)
        br.addWidget(self.summarize_btn)

        for label, slot in [("📋  History", self._show_history),
                             ("💾  Export",  self._export_log),
                             ("🗑  Clear",   self._clear_log)]:
            btn = QPushButton(label); btn.clicked.connect(slot); br.addWidget(btn)

        self.settings_btn = QPushButton("⚙  Settings")
        self.settings_btn.clicked.connect(self._show_settings)
        br.addWidget(self.settings_btn)
        self._update_settings_badge()
        root.addLayout(br)

    def _auto_detect(self, text: str):
        if self.type_combo.currentText() == "Auto-Detect" and text.strip():
            self.status_lbl.setText(f"Auto-detected: {detect_input_type(text)}")

    def _append_html_wrap(self, msg: str, colour: str):
        """Like _append_html but allows word wrapping — used for Claude summary."""
        import re as _re
        escaped = html_escape(msg)
        def _linkify(m):
            raw_url = m.group(0)
            return f'<a href="{raw_url}" style="color:#00AAFF;text-decoration:underline;">{raw_url}</a>'
        linked = _re.sub(r'https?://[^\s<>"]+', _linkify, escaped)
        self.log_view.append(
            f'<span style="color:{colour};font-family:Courier;font-size:11pt;white-space:normal;">{linked}</span>'
        )
        self.log_view.moveCursor(QTextCursor.MoveOperation.End)

    def _append_html(self, msg: str, colour: str):
        escaped = html_escape(msg)
        # Linkify URLs — wrap http(s):// URLs in anchor tags
        import re as _re
        def _linkify(m):
            raw_url = m.group(0)
            # html_escape already ran, so unescape for the href then re-escape display
            href = raw_url  # already escaped, suitable for href
            return (
                f'<a href="{href}" style="color:#00AAFF;text-decoration:underline;">' 
                f'{raw_url}</a>'
            )
        # Match escaped URLs (html_escape turns & to &amp; in URLs)
        linked = _re.sub(r'https?://[^\s<>"]+', _linkify, escaped)
        self.log_view.append(
            f'<span style="color:{colour};font-family:Courier;font-size:11pt;">{linked}</span>'
        )
        self.log_view.moveCursor(QTextCursor.MoveOperation.End)

    def _start_search(self):
        self._dbg_main("_start_search called")
        query = self.search_bar.text().strip()
        if not query: return
        chosen     = self.type_combo.currentText()
        input_type = detect_input_type(query) if chosen == "Auto-Detect" else chosen
        extended   = self.ext_cb.isChecked()
        self._dbg_main(f"query={query!r} type={input_type} extended={extended}")
        self.search_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.status_lbl.setText(f"Scanning: {query} [{input_type}]...")
        self._dbg_main("creating OSINTThread")
        self.thread = OSINTThread(query, input_type, extended, config=self.config)
        self._dbg_main("connecting OSINTThread signals")
        self.thread.log_signal.connect(self._append_html)
        self.thread.done_signal.connect(lambda: self._on_done(query, input_type))
        self.thread.finished.connect(self.thread.deleteLater)
        self._dbg_main("starting OSINTThread")
        self.thread.start()
        self._dbg_main("OSINTThread started")

    def _stop_search(self):
        # Signal threads to stop — don't block waiting for them
        # Blocking wait() on main thread while thread holds network connections = crash
        if self.thread:
            self.thread.stop()
            # Let the thread finish naturally via done_signal → _on_done
            # Just disable stop button and update status
        if self.deep_thread:
            self.deep_thread.stop()
        self.stop_btn.setEnabled(False)
        self.status_lbl.setText("Stopping...")
        # Re-enable search after a short delay to let threads wind down
        QTimer.singleShot(1000, self._on_stop_complete)

    def _on_stop_complete(self):
        self.search_btn.setEnabled(True)
        self.status_lbl.setText("Stopped.")

    def _on_done(self, query: str, input_type: str):
        self._dbg_main("_on_done START")
        self.search_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status_lbl.setText(f"Scan complete: {query}")
        self._dbg_main("getting log text")
        log_text = self.log_view.toPlainText()
        self._last_log = log_text
        self._dbg_main("saving history")
        self.history.add(query, input_type, log_text)
        self._dbg_main("history saved")
        if input_type == "Name" and self.ext_cb.isChecked():
            self._append_html(
                f"[{datetime.now().strftime('%H:%M:%S')}]  ══  Standard scan complete — starting deep search...  ══",
                COL_HEAD
            )
            QTimer.singleShot(1500, lambda: self._start_deep_search(query))
        elif self.config.scan("auto_summarize") and self.config.key("anthropic"):
            self._dbg_main("triggering auto summarize")
            QTimer.singleShot(500, self._run_summary)
        self._dbg_main("_on_done END")
        self._dbg_main("waiting for thread cleanup")

    def _start_deep_search(self, query: str):
        self._dbg_main("_start_deep_search BEGIN")
        self.search_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.status_lbl.setText(f"Deep search: {query}...")
        self._dbg_main("creating DeepSearchThread")
        self.deep_thread = DeepSearchThread(query, self.config)
        self._dbg_main("connecting signals")
        self.deep_thread.log_signal.connect(self._append_html)
        self.deep_thread.done_signal.connect(lambda: self._on_deep_done(query))
        self.deep_thread.finished.connect(self.deep_thread.deleteLater)
        # Timer to drain the log queue and update UI during deep scan
        self._deep_timer = QTimer()
        self._deep_timer.setInterval(200)
        self._deep_timer.timeout.connect(self._drain_deep_queue)
        self._deep_timer.start()
        self._dbg_main("starting deep thread")
        self.deep_thread.start()
        self._dbg_main("deep thread started")

    def _drain_deep_queue(self):
        """Drain log queue from DeepSearchThread and update UI."""
        if self.deep_thread and hasattr(self.deep_thread, "_queue"):
            try:
                while not self.deep_thread._queue.empty():
                    msg, col = self.deep_thread._queue.get_nowait()
                    self._append_html(msg, col)
            except Exception:
                pass

    def _on_deep_done(self, query: str):
        # Stop the drain timer
        if hasattr(self, "_deep_timer") and self._deep_timer:
            self._deep_timer.stop()
            self._deep_timer = None
        # Final drain
        self._drain_deep_queue()
        self.search_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status_lbl.setText(f"Deep search complete: {query}")
        log_text = self.log_view.toPlainText()
        self._last_log = log_text
        if self.config.scan("auto_summarize") and self.config.key("anthropic"):
            QTimer.singleShot(500, self._run_summary)



    def _dbg_main(self, msg: str):
        """Write main-thread debug checkpoint."""
        try:
            dbg_path = APP_DATA_DIR / "osint_crash_debug.txt"
            with open(dbg_path, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().strftime('%H:%M:%S.%f')} [MAIN] {msg}\n")
                f.flush()
                import os; os.fsync(f.fileno())
        except Exception:
            pass

    def _restore_geometry(self):
        geo = self.config.data.get("window", {})
        if geo.get("width") and geo.get("height"):
            self.resize(int(geo["width"]), int(geo["height"]))
            if geo.get("x") is not None and geo.get("y") is not None:
                self.move(int(geo["x"]), int(geo["y"]))
        else:
            self.resize(1280, 860)

    def closeEvent(self, event):
        geo = self.geometry()
        self.config.data["window"] = {
            "x": geo.x(), "y": geo.y(),
            "width": geo.width(), "height": geo.height(),
        }
        self.config.save()
        event.accept()

    def _clear_log(self): self.log_view.clear()

    def _export_log(self):
        text = self.log_view.toPlainText()
        if not text.strip():
            QMessageBox.information(self, "Export", "Nothing to export."); return
        q    = self.search_bar.text().strip().replace(" ", "_")[:30]
        name = f"osint_{q}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        path, _ = QFileDialog.getSaveFileName(self, "Export Log", name, "Text files (*.txt)")
        if path:
            Path(path).write_text(text, encoding="utf-8")
            self.status_lbl.setText(f"Exported: {path}")


    def _run_summary(self):
        key   = self.config.key("anthropic")
        if not key:
            QMessageBox.warning(self, "No Key",
                "Add your Anthropic API key in Settings to use AI summaries.")
            return
        log_text = self.log_view.toPlainText()
        if not log_text.strip():
            QMessageBox.information(self, "Empty", "Nothing to summarize.")
            return
        query      = self.search_bar.text().strip()
        chosen     = self.type_combo.currentText()
        input_type = detect_input_type(query) if chosen == "Auto-Detect" else chosen
        model      = self.config.scan("claude_model")
        deep_findings = self.deep_thread.findings() if self.deep_thread else None

        self.status_lbl.setText("Running Claude AI summary...")
        self.summarize_btn.setEnabled(False)
        QApplication.processEvents()

        def do_summary():
            return run_claude_summary(log_text, query, input_type, key, model,
                                     deep_findings=deep_findings)

        import threading
        result = [None, None]
        def run():
            result[0], result[1] = do_summary()
        t = threading.Thread(target=run, daemon=True)
        t.start()
        t.join(timeout=90)

        self.summarize_btn.setEnabled(True)
        ok, text = result
        if ok is None:
            self.status_lbl.setText("Claude summary timed out.")
            return
        if ok:
            self._append_html("", COL_HEAD)
            self._append_html("══  CLAUDE AI INTELLIGENCE REPORT  " + "═"*24, COL_HEAD)
            self._append_html(f"    Model: {model}", COL_INFO)
            self._append_html("", COL_INFO)
            # Claude summary uses word wrap — emit with wrap style
            for line in text.splitlines():
                col = COL_HEAD if line.startswith("#") else COL_OK if line.startswith("**") else COL_INFO
                self._append_html_wrap(line, col)
            self._append_html("══  END OF REPORT  " + "═"*40, COL_HEAD)
            self.status_lbl.setText("Claude summary complete.")
        else:
            self._append_html(f"Claude summary failed: {text}", COL_ERR)
            self.status_lbl.setText("Claude summary failed.")

    def _show_settings(self):
        dlg = SettingsDialog(self.config, self)
        dlg.exec()
        self._update_settings_badge()
        # Apply any scan defaults that changed
        # Deep Search default not persisted — always starts unchecked

    def _update_settings_badge(self):
        if self.config.has_any_key():
            self.settings_btn.setText("⚙  Settings")
            self.settings_btn.setStyleSheet("")
        else:
            self.settings_btn.setText("⚙  Settings ●")
            self.settings_btn.setStyleSheet(
                f"background:{C_DARK}; color:{COL_WARN}; border:1px solid {COL_WARN}; "
                f"padding:7px 14px; font-family:Courier; font-size:12px; font-weight:bold;"
            )

    def _show_history(self):
        dlg = HistoryDialog(self.history, self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.rerun_entry:
            e = dlg.rerun_entry
            self.search_bar.setText(e.get("query", ""))
            t   = e.get("type", "Auto-Detect")
            idx = INPUT_TYPES.index(t) if t in INPUT_TYPES else 0
            self.type_combo.setCurrentIndex(idx)
            self._start_search()


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
def main():
    if sys.platform == "win32":
        try:
            from ctypes import windll; windll.user32.SetProcessDPIAware()
        except Exception:
            pass

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    splash = create_splash()
    if splash:
        splash.show()
        for msg in ["Initializing OSINT modules...", "Loading site registry...",
                    "Preparing DNS resolvers...", "Ready to hunt..."]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            time.sleep(0.5)

    win = OSINTMainWindow()
    if sys.platform.startswith("linux"):
        win.showNormal()
        QTimer.singleShot(100, win.showMaximized)
    else:
        win.show()

    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
